package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.border.*;

public class Login extends JFrame implements ActionListener {
    
    JLabel l1, l2, l3;
    JTextField t1;
    JPasswordField t2;
    JButton b1, b2;
    JPanel mainPanel, formPanel;

    Login() {
        super("Hotel Management System");
        
        // Make frame undecorated to remove system title bar
        setUndecorated(true);
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Main panel with background gradient
        mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color color1 = new Color(240, 240, 240);
                Color color2 = new Color(220, 220, 220);
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Custom title bar
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(70, 130, 180));
        
        JLabel titleLabel = new JLabel("Login - Hotel Management System");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(new EmptyBorder(5, 10, 5, 10));
        titlePanel.add(titleLabel, BorderLayout.WEST);
        
        // Close button
        JButton closeButton = new JButton("×");
        closeButton.setFont(new Font("Arial", Font.BOLD, 18));
        closeButton.setContentAreaFilled(false);
        closeButton.setBorderPainted(false);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> System.exit(0));
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(new Color(255, 100, 100));
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(Color.WHITE);
            }
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(closeButton);
        titlePanel.add(buttonPanel, BorderLayout.EAST);
        
        // Form panel with modern styling
        formPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 25, 25);
                g2.setColor(new Color(200, 200, 200));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 25, 25);
            }
        };
        formPanel.setLayout(null);
        formPanel.setOpaque(false);
        formPanel.setPreferredSize(new Dimension(350, 400));
        formPanel.setBorder(new EmptyBorder(30, 30, 30, 30));

        // Header label with icon
        JLabel header = new JLabel("Welcome Back", SwingConstants.CENTER);
        header.setBounds(0, 20, 290, 40);
        header.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.setForeground(new Color(70, 130, 180));
        formPanel.add(header);
        
        JLabel subHeader = new JLabel("Please login to continue", SwingConstants.CENTER);
        subHeader.setBounds(0, 60, 290, 20);
        subHeader.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subHeader.setForeground(new Color(120, 120, 120));
        formPanel.add(subHeader);

        // Username label and field
        l1 = new JLabel("Username");
        l1.setBounds(40, 100, 100, 25);
        l1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        l1.setForeground(new Color(80, 80, 80));
        formPanel.add(l1);
        
        t1 = new JTextField();
        t1.setBounds(40, 125, 270, 40);
        t1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        t1.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200), 1, true), 
            new EmptyBorder(5, 15, 5, 15)
        ));
        formPanel.add(t1);

        // Password label and field
        l2 = new JLabel("Password");
        l2.setBounds(40, 175, 100, 25);
        l2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        l2.setForeground(new Color(80, 80, 80));
        formPanel.add(l2);

        t2 = new JPasswordField();
        t2.setBounds(40, 200, 270, 40);
        t2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        t2.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(200, 200, 200), 1, true), 
            new EmptyBorder(5, 15, 5, 15)
        ));
        formPanel.add(t2);

        // Login button
        b1 = new JButton("LOGIN");
        b1.setBounds(40, 270, 270, 45);
        b1.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b1.setBackground(new Color(70, 130, 180));
        b1.setForeground(Color.WHITE);
        b1.setFocusPainted(false);
        b1.setBorderPainted(false);
        b1.setBorder(new EmptyBorder(5, 15, 5, 15));
        b1.addActionListener(this);
        
        // Hover effect for login button
        b1.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                b1.setBackground(new Color(65, 105, 225));
                b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(MouseEvent e) {
                b1.setBackground(new Color(70, 130, 180));
                b1.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
        formPanel.add(b1);

        // Image panel with shadow effect
        JPanel imagePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw shadow
                int shadowSize = 10;
                for (int i = 0; i < shadowSize; i++) {
                    float opacity = 0.1f - (i * 0.1f / shadowSize);
                    g2d.setColor(new Color(0, 0, 0, opacity));
                    g2d.fillRoundRect(i, i, getWidth() - 2*i, getHeight() - 2*i, 20, 20);
                }
                
                // Draw white background
                g2d.setColor(Color.WHITE);
                g2d.fillRoundRect(0, 0, getWidth()-shadowSize, getHeight()-shadowSize, 20, 20);
            }
        };
        imagePanel.setOpaque(false);
        imagePanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        ImageIcon originalIcon = new ImageIcon(ClassLoader.getSystemResource("icons/second.jpg"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(400, 400, Image.SCALE_SMOOTH);
        JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imagePanel.add(imageLabel, BorderLayout.CENTER);

        // Add components to main panel
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.WEST);
        mainPanel.add(imagePanel, BorderLayout.CENTER);

        // Add main panel to frame
        this.add(mainPanel);

        // Window settings
        setSize(850, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            try {
                Conn c1 = new Conn();
                String u = t1.getText();
                String v = new String(t2.getPassword());
                
                String q = "select * from login where username='"+u+"' and password='"+v+"'";
                
                ResultSet rs = c1.s.executeQuery(q); 
                if (rs.next()) {
                    dispose();
                    new Dashboard();
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Invalid username or password", 
                        "Login Failed", 
                        JOptionPane.ERROR_MESSAGE);
                    t1.setText("");
                    t2.setText("");
                    t1.requestFocus();
                }
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, 
                    "Database error: " + e.getMessage(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] arg) {
        SwingUtilities.invokeLater(() -> new Login());
    }
}