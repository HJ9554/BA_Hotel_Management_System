package hotel.management.system;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import javax.swing.JTable;
import java.sql.*;	
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ManagerInfo extends JFrame {
    Connection conn = null;
    private JPanel contentPane;
    private JTable table;
    private JLabel lblNewLabel;
    private JLabel lblJob;
    private JLabel lblName;
    private JLabel lblDepartment;
    private JPanel titlePanel;
    private JLabel titleLabel;
    private JButton closeButton;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ManagerInfo frame = new ManagerInfo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void close() {
        this.dispose();
    }

    public ManagerInfo() throws SQLException {
        setUndecorated(true); // Remove default title bar
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(350, 100, 1030, 700);
        
        // Create custom title bar
        createTitleBar();
        
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // Add the title bar to the content pane
        contentPane.add(titlePanel);
        
        JLabel heading = new JLabel("Manager Information");
        heading.setFont(new Font("Tahoma", Font.BOLD, 20));
        heading.setBounds(400, 45, 250, 30);
        heading.setForeground(new Color(128, 0, 128)); // Dark purple
        contentPane.add(heading);
        
        table = new JTable();
        table.setBackground(new Color(240, 240, 240));
        table.setGridColor(Color.GRAY);
        table.setSelectionBackground(new Color(128, 0, 128));
        table.setTableHeader(null);
        table.setSelectionForeground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 130, 1000, 450); // Adjusted y position
        contentPane.add(scrollPane);
        
        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Conn c = new Conn();
                    String displayCustomersql = "select * from Employee where job = 'Manager'";
                    ResultSet rs = c.s.executeQuery(displayCustomersql);
                    
                    if (!rs.isBeforeFirst()) {
                        JOptionPane.showMessageDialog(null, "No manager records found!", "Information", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        table.setModel(DbUtils.resultSetToTableModel(rs));
                        table.setTableHeader(null);
                        JOptionPane.showMessageDialog(null, "Data loaded successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(null, "Error loading data: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    e1.printStackTrace();
                }
            }
        });
        btnLoadData.setBounds(350, 600, 120, 30);
        btnLoadData.setBackground(new Color(128, 0, 128));
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.setFocusPainted(false);
        btnLoadData.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnLoadData.setOpaque(true);
        btnLoadData.setBorderPainted(false);
        contentPane.add(btnLoadData);
        
        JButton btnExit = new JButton("Back to Reception");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Reception().setVisible(true);
                dispose();
            }
        });
        btnExit.setBounds(500, 600, 150, 30);
        btnExit.setBackground(Color.BLACK);
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnExit.setOpaque(true);
        btnExit.setBorderPainted(false);
        contentPane.add(btnExit);
        
        // Column headers - increased height to 25px and adjusted positions
        lblNewLabel = new JLabel("Name");
        lblNewLabel.setBounds(41, 100, 60, 25); // Increased height
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(lblNewLabel);
        
        lblJob = new JLabel("Age");
        lblJob.setBounds(159, 100, 60, 25); // Increased height
        lblJob.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblJob.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(lblJob);
        
        lblName = new JLabel("Gender");
        lblName.setBounds(273, 100, 60, 25); // Increased height
        lblName.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblName.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(lblName);
        
        lblDepartment = new JLabel("Job");
        lblDepartment.setBounds(416, 100, 80, 25); // Increased height
        lblDepartment.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblDepartment.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(lblDepartment);
        
        JLabel l1 = new JLabel("Salary");
        l1.setBounds(536, 100, 80, 25); // Increased height
        l1.setFont(new Font("Tahoma", Font.BOLD, 12));
        l1.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(l1);
        
        JLabel l2 = new JLabel("Phone");
        l2.setBounds(656, 100, 80, 25); // Increased height
        l2.setFont(new Font("Tahoma", Font.BOLD, 12));
        l2.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(l2);
        
        JLabel l3 = new JLabel("Email");
        l3.setBounds(786, 100, 80, 25); // Increased height
        l3.setFont(new Font("Tahoma", Font.BOLD, 12));
        l3.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(l3);
        
        JLabel l4 = new JLabel("Aadhar");
        l4.setBounds(896, 100, 80, 25); // Increased height
        l4.setFont(new Font("Tahoma", Font.BOLD, 12));
        l4.setVerticalAlignment(SwingConstants.BOTTOM);
        contentPane.add(l4);
        
        getContentPane().setBackground(Color.WHITE);
    }
    
    private void createTitleBar() {
        titlePanel = new JPanel();
        titlePanel.setBounds(0, 0, 1030, 30);
        titlePanel.setBackground(new Color(128, 0, 128)); // Dark purple
        titlePanel.setLayout(null);
        
        // Title label
        titleLabel = new JLabel("Hotel Management System - Manager Info");
        titleLabel.setBounds(10, 0, 400, 30);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titlePanel.add(titleLabel);
        
        // Close button
        closeButton = new JButton("X");
        closeButton.setBounds(1000, 0, 30, 30);
        closeButton.setForeground(Color.WHITE);
        closeButton.setBorder(BorderFactory.createEmptyBorder());
        closeButton.setBackground(new Color(128, 0, 128));
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        
        // Hover effects for close button
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(Color.RED);
                
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(new Color(128, 0, 128));
                
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        titlePanel.add(closeButton);
    }
}