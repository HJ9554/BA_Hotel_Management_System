package hotel.management.system;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class UpdateCheck extends JFrame implements ActionListener {
    
    private Choice ccustomer;
    private JTextField tfroom, tfname, tfcheckin, tfpaid, tfpending;
    private JButton check, update, back;
    private int xMouse, yMouse;
    
    UpdateCheck() {
        // Remove default title bar
        setUndecorated(true);
        // Set rounded corners
        setShape(new RoundRectangle2D.Double(0, 0, 980, 500, 20, 20));
        
        getContentPane().setBackground(new Color(245, 245, 245));
        setLayout(null);
        
        // Custom Title Bar
        JPanel titleBar = new JPanel();
        titleBar.setBounds(0, 0, 980, 40);
        titleBar.setBackground(new Color(70, 130, 180));
        titleBar.setLayout(null);
        titleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });
        titleBar.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                setLocation(x - xMouse, y - yMouse);
            }
        });
        
        JLabel title = new JLabel("Update Check-In Status");
        title.setBounds(20, 0, 300, 40);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Tahoma", Font.BOLD, 16));
        titleBar.add(title);
        
        // Close button
        JButton closeBtn = new JButton("×");
        closeBtn.setBounds(930, 0, 50, 40);
        closeBtn.setFont(new Font("Arial", Font.BOLD, 24));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setBackground(new Color(70, 130, 180));
        closeBtn.setBorder(BorderFactory.createEmptyBorder());
        closeBtn.setFocusPainted(false);
        closeBtn.setContentAreaFilled(false);
        closeBtn.setOpaque(true);
        closeBtn.addActionListener(e -> dispose());
        
        closeBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeBtn.setBackground(new Color(200, 50, 50));
            }
            public void mouseExited(MouseEvent e) {
                closeBtn.setBackground(new Color(70, 130, 180));
            }
        });
        titleBar.add(closeBtn);
        
        add(titleBar);
        
        // Main content
        JPanel mainPanel = new JPanel();
        mainPanel.setBounds(20, 60, 940, 400);
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230), 1));
        mainPanel.setLayout(null);
        add(mainPanel);
        
        JLabel text = new JLabel("Update Status");
        text.setFont(new Font("Tahoma", Font.BOLD, 18));
        text.setBounds(30, 20, 200, 30);
        text.setForeground(new Color(70, 130, 180));
        mainPanel.add(text);
        
        JLabel lblid = new JLabel("Customer ID:");
        lblid.setBounds(30, 70, 150, 20);
        lblid.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(lblid);
        
        ccustomer = new Choice();
        ccustomer.setBounds(200, 70, 200, 25);
        ccustomer.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(ccustomer);
        
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from customer");
            while(rs.next()) {
                ccustomer.add(rs.getString("number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading customer data");
        }
        
        JLabel lblroom = new JLabel("Room Number:");
        lblroom.setBounds(30, 110, 150, 20);
        lblroom.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(lblroom);
        
        tfroom = new JTextField();
        tfroom.setBounds(200, 110, 200, 30);
        tfroom.setFont(new Font("Tahoma", Font.PLAIN, 14));
        tfroom.setEditable(false);
        mainPanel.add(tfroom);
        
        JLabel lblname = new JLabel("Name:");
        lblname.setBounds(30, 150, 150, 20);
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(lblname);
        
        tfname = new JTextField();
        tfname.setBounds(200, 150, 200, 30);
        tfname.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(tfname);
        
        JLabel lblcheckin = new JLabel("Check-In Time:");
        lblcheckin.setBounds(30, 190, 150, 20);
        lblcheckin.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(lblcheckin);
        
        tfcheckin = new JTextField();
        tfcheckin.setBounds(200, 190, 200, 30);
        tfcheckin.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(tfcheckin);
        
        JLabel lblpaid = new JLabel("Amount Paid:");
        lblpaid.setBounds(30, 230, 150, 20);
        lblpaid.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(lblpaid);
        
        tfpaid = new JTextField();
        tfpaid.setBounds(200, 230, 200, 30);
        tfpaid.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(tfpaid);
        
        JLabel lblpending = new JLabel("Pending Amount:");
        lblpending.setBounds(30, 270, 150, 20);
        lblpending.setFont(new Font("Tahoma", Font.PLAIN, 14));
        mainPanel.add(lblpending);
        
        tfpending = new JTextField();
        tfpending.setBounds(200, 270, 200, 30);
        tfpending.setFont(new Font("Tahoma", Font.PLAIN, 14));
        tfpending.setEditable(false);
        mainPanel.add(tfpending);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(30, 320, 370, 50);
        buttonPanel.setLayout(new GridLayout(1, 3, 10, 0));
        buttonPanel.setOpaque(false);
        
        check = createButton("Check", new Color(70, 130, 180), Color.WHITE);
        buttonPanel.add(check);
        
        update = createButton("Update", new Color(65, 150, 65), Color.WHITE);
        buttonPanel.add(update);
        
        back = createButton("Back", new Color(200, 70, 70), Color.WHITE);
        buttonPanel.add(back);
        
        mainPanel.add(buttonPanel);
        
        // Image panel
        JPanel imagePanel = new JPanel();
        imagePanel.setBounds(450, 70, 450, 300);
        imagePanel.setBackground(Color.WHITE);
        imagePanel.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230), 1));
        imagePanel.setLayout(new BorderLayout());
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/nine.jpg"));
        Image img = i1.getImage().getScaledInstance(450, 300, Image.SCALE_SMOOTH);
        JLabel image = new JLabel(new ImageIcon(img));
        image.setHorizontalAlignment(JLabel.CENTER);
        imagePanel.add(image);
        
        mainPanel.add(imagePanel);
        
        setSize(980, 500);
        setLocationRelativeTo(null);
        setVisible(true);
        
    }
    
    private JButton createButton(String text, Color bgColor, Color textColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(textColor);
        button.setFont(new Font("Tahoma", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(bgColor.darker(), 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.brighter());
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(bgColor.darker().darker(), 1),
                    BorderFactory.createEmptyBorder(8, 15, 8, 15)
                ));
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(bgColor.darker(), 1),
                    BorderFactory.createEmptyBorder(8, 15, 8, 15)
                ));
            }
        });
        
        button.addActionListener(this);
        return button;
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == check) {
            String id = ccustomer.getSelectedItem();
            if (id == null || id.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please select a customer ID");
                return;
            }
            
            String query = "select * from customer where number = '"+id+"'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                if (!rs.isBeforeFirst()) {
                    JOptionPane.showMessageDialog(null, "No customer found with this ID");
                    return;
                }
                
                while(rs.next()){
                    tfroom.setText(rs.getString("room"));
                    tfname.setText(rs.getString("name"));
                    tfcheckin.setText(rs.getString("checkintime"));
                    tfpaid.setText(rs.getString("deposit"));
                }
                
                ResultSet rs2 = c.s.executeQuery("select * from room where roomnumber = '"+tfroom.getText()+"'");
                if (rs2.next()) {
                    String price = rs2.getString("price");
                    try {
                        double amountPaid = Double.parseDouble(price) - Double.parseDouble(tfpaid.getText());
                        tfpending.setText(String.format("%.2f", amountPaid));
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid amount format");
                        tfpending.setText("");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            }
            
        } else if (ae.getSource() == update) {
            // Validate all fields before update
            if (tfroom.getText().trim().isEmpty() || tfname.getText().trim().isEmpty() || 
                tfcheckin.getText().trim().isEmpty() || tfpaid.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all required fields");
                return;
            }
            
            try {
                Double.parseDouble(tfpaid.getText());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid amount");
                return;
            }
            
            String number = ccustomer.getSelectedItem();
            String room = tfroom.getText();
            String name = tfname.getText();
            String checkin = tfcheckin.getText();
            String deposit = tfpaid.getText();
            
            try {
                Conn c = new Conn();
                int rowsAffected = c.s.executeUpdate("update customer set room = '"+room+"', name = '"+name+"', checkintime = '"+checkin+"', deposit = '"+deposit+"' where number = '"+number+"'");
                
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Data Updated Successfully");
                    dispose();
                    new Reception();
                } else {
                    JOptionPane.showMessageDialog(null, "Update failed. No records were updated.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            }
            
        } else if (ae.getSource() == back) {
            new Reception().setVisible(true);
            dispose();
        }
    }
    
    public static void main(String[] args) {
            new UpdateCheck();
        
    }
}