package hotel.management.system;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SearchRoom extends JFrame {
    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private JPanel contentPane;
    private JTable table;
    Choice c1;
    private int xMouse, yMouse;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SearchRoom frame = new SearchRoom();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void close() {
        this.dispose();
    }

    public SearchRoom() throws SQLException {
        // Remove default title bar
        setUndecorated(true);
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(530, 200, 730, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // Custom Title Bar Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 120, 215));
        titlePanel.setBounds(0, 0, 730, 40);
        titlePanel.setLayout(null);
        titlePanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });
        titlePanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                setLocation(x - xMouse, y - yMouse);
            }
        });
        contentPane.add(titlePanel);
        
        // Title Label
        JLabel lblTitle = new JLabel("Search For Room");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(10, 5, 200, 30);
        titlePanel.add(lblTitle);
        
        // Close Button
        JButton closeButton = new JButton("X");
        closeButton.setBounds(690, 5, 40, 30);
        closeButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        closeButton.setBackground(new Color(0, 120, 215));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBorder(BorderFactory.createEmptyBorder());
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(Color.RED);
                closeButton.setOpaque(true);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(null);
                closeButton.setOpaque(false);
            }
        });
        
        closeButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        titlePanel.add(closeButton);
        
        JLabel lblRoomAvailable = new JLabel("Room Bed Type:");
        lblRoomAvailable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblRoomAvailable.setBounds(50, 60, 120, 20);
        contentPane.add(lblRoomAvailable);
        
        c1 = new Choice();
        c1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        c1.add("Single Bed");
        c1.add("Double Bed");
        c1.setBounds(180, 60, 150, 20);
        contentPane.add(c1);
        
        JCheckBox checkRoom = new JCheckBox("Only display Available");
        checkRoom.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        checkRoom.setBounds(400, 60, 200, 20);
        checkRoom.setBackground(Color.WHITE);
        contentPane.add(checkRoom);
        
        // Table header labels with styling
        JLabel lblRoomNumber = new JLabel("Room Number");
        lblRoomNumber.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRoomNumber.setBounds(35, 125, 100, 20);
        contentPane.add(lblRoomNumber);
        
        JLabel lblAvailability = new JLabel("Availability");
        lblAvailability.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblAvailability.setBounds(200, 125, 100, 20);
        contentPane.add(lblAvailability);
        
        JLabel lblCleanStatus = new JLabel("Clean Status");
        lblCleanStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCleanStatus.setBounds(330, 125, 100, 20);
        contentPane.add(lblCleanStatus);
        
        JLabel lblPrice = new JLabel("Price");
        lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPrice.setBounds(480, 125, 100, 20);
        contentPane.add(lblPrice);
        
        JLabel lblBedType = new JLabel("Bed Type");
        lblBedType.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblBedType.setBounds(595, 125, 100, 20);
        contentPane.add(lblBedType);
        
        // Table with scroll pane
        table = new JTable();
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setTableHeader(null);
        table.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 150, 690, 200);
        contentPane.add(scrollPane);
        
        // Search Button with gradient
        JButton btnSearch = new JButton("Search");
        styleButton(btnSearch);
        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (c1.getSelectedItem() == null || c1.getSelectedItem().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please select a bed type", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                String SQL = "SELECT * FROM Room WHERE bed_type = '"+c1.getSelectedItem()+"'";
                String SQL2 = "SELECT * FROM Room WHERE availability = 'Available' AND bed_type = '"+c1.getSelectedItem()+"'";
                
                try {
                    Conn c = new Conn();
                    if (checkRoom.isSelected()) {
                        rs = c.s.executeQuery(SQL2);
                    } else {
                        rs = c.s.executeQuery(SQL);
                    }
                    
                    if (!rs.isBeforeFirst()) {
                        JOptionPane.showMessageDialog(null, "No rooms found with selected criteria", "Information", JOptionPane.INFORMATION_MESSAGE);
                    }
                    
                    table.setModel(DbUtils.resultSetToTableModel(rs));
                    table.setTableHeader(null);
                } catch (SQLException ss) {
                    JOptionPane.showMessageDialog(null, "Database error: " + ss.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ss.printStackTrace();
                }
            }
        });
        btnSearch.setBounds(200, 380, 120, 35);
        contentPane.add(btnSearch);
        
        // Back Button with gradient
        JButton btnExit = new JButton("Back");
        styleButton(btnExit);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Reception().setVisible(true);
                dispose();
            }
        });
        btnExit.setBounds(380, 380, 120, 35);
        contentPane.add(btnExit);
        
        // Add some visual improvements
        contentPane.setBackground(Color.WHITE);
        
        // Add shadow effect to the window
        
        RootPaneContainer root = (RootPaneContainer) this;
        root.getRootPane().setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, new Color(150, 150, 150)));
    }
    
    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        button.setBackground(new Color(0, 120, 215));
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(0, 150, 255));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(0, 120, 215));
            }
        });
    }
}