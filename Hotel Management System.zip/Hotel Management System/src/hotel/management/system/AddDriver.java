package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.regex.*;

public class AddDriver extends JFrame implements ActionListener {
    
    JButton add, cancel;
    JTextField tfname, tfage, tfcompany, tfmodel, tflocation;
    JComboBox<String> availablecombo, gendercombo;  
    JLabel errorLabel;
    
    AddDriver(JFrame parent) {
        // Window setup
        setUndecorated(true);
        setSize(1000, 550);
        setLayout(null);
        
        // Position relative to parent window
        if (parent != null) {
            Point parentLocation = parent.getLocation();
            setLocation(parentLocation.x + 50, parentLocation.y + 50);
        } else {
            setLocationRelativeTo(null);
        }
        
        getContentPane().setBackground(new Color(240, 240, 240));

        // Custom title bar
        JPanel titleBar = new JPanel();
        titleBar.setBackground(new Color(25, 25, 112));
        titleBar.setBounds(0, 0, 1000, 40);
        titleBar.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Add New Driver");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        titleBar.add(titleLabel, BorderLayout.WEST);
        
        JButton closeButton = new JButton("×");
        closeButton.setFont(new Font("Arial", Font.BOLD, 20));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(new Color(25, 25, 112));
        closeButton.setFocusPainted(false);
        closeButton.setBorderPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        closeButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 15));
        closeButton.addActionListener(e -> dispose());
        
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(Color.RED);
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(Color.WHITE);
            }
        });
        
        titleBar.add(closeButton, BorderLayout.EAST);
        add(titleBar);

        // Main content panel
        JPanel mainPanel = new JPanel();
        mainPanel.setBounds(0, 40, 1000, 510);
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(null);
        add(mainPanel);

        // Form components
        JLabel heading = new JLabel("Driver Details");
        heading.setFont(new Font("Tahoma", Font.BOLD, 18));
        heading.setForeground(new Color(25, 25, 112));
        heading.setBounds(150, 20, 200, 30);
        mainPanel.add(heading);

        errorLabel = new JLabel("");
        errorLabel.setForeground(Color.RED);
        errorLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        errorLabel.setBounds(200, 420, 400, 30);
        mainPanel.add(errorLabel);

        // Name field
        JLabel lblname = new JLabel("Name");
        lblname.setForeground(new Color(25, 25, 112));
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblname.setBounds(60, 70, 120, 30);
        mainPanel.add(lblname);
        
        tfname = new JTextField();
        tfname.setBounds(200, 70, 250, 30);
        tfname.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(150, 150, 150)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        mainPanel.add(tfname);

        // Age field
        JLabel lblage = new JLabel("Age");
        lblage.setForeground(new Color(25, 25, 112));
        lblage.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblage.setBounds(60, 120, 120, 30);
        mainPanel.add(lblage);
        
        tfage = new JTextField();
        tfage.setBounds(200, 120, 250, 30);
        tfage.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(150, 150, 150)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        mainPanel.add(tfage);
        
        // Gender field
        JLabel lblgender = new JLabel("Gender");
        lblgender.setForeground(new Color(25, 25, 112));
        lblgender.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblgender.setBounds(60, 170, 120, 30);
        mainPanel.add(lblgender);
        
        String genderOptions[] = { "Male", "Female", "Other" };
        gendercombo = new JComboBox<>(genderOptions);
        gendercombo.setBounds(200, 170, 250, 30);
        gendercombo.setBackground(Color.WHITE);
        gendercombo.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150)));
        mainPanel.add(gendercombo);

        // Car Company field
        JLabel lblcompany = new JLabel("Car Company");
        lblcompany.setForeground(new Color(25, 25, 112));
        lblcompany.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblcompany.setBounds(60, 220, 120, 30);
        mainPanel.add(lblcompany);

        tfcompany = new JTextField();
        tfcompany.setBounds(200, 220, 250, 30);
        tfcompany.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(150, 150, 150)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        mainPanel.add(tfcompany);

        // Car Model field
        JLabel lblmodel = new JLabel("Car Model");
        lblmodel.setForeground(new Color(25, 25, 112));
        lblmodel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblmodel.setBounds(60, 270, 120, 30);
        mainPanel.add(lblmodel);
        
        tfmodel = new JTextField();
        tfmodel.setBounds(200, 270, 250, 30);
        tfmodel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(150, 150, 150)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        mainPanel.add(tfmodel);
        
        // Availability field
        JLabel lblavailable = new JLabel("Availability");
        lblavailable.setForeground(new Color(25, 25, 112));
        lblavailable.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblavailable.setBounds(60, 320, 120, 30);
        mainPanel.add(lblavailable);
        
        String availableOptions[] = { "Available", "Busy" };
        availablecombo = new JComboBox<>(availableOptions);
        availablecombo.setBounds(200, 320, 250, 30);
        availablecombo.setBackground(Color.WHITE);
        availablecombo.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150)));
        mainPanel.add(availablecombo);
        
        // Location field
        JLabel lbllocation = new JLabel("Location");
        lbllocation.setForeground(new Color(25, 25, 112));
        lbllocation.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lbllocation.setBounds(60, 370, 120, 30);
        mainPanel.add(lbllocation);
        
        tflocation = new JTextField();
        tflocation.setBounds(200, 370, 250, 30);
        tflocation.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(150, 150, 150)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        mainPanel.add(tflocation);
        
        // Action buttons - now properly positioned and visible
        add = new JButton("Add Driver");
        add.addActionListener(this);
        add.setBounds(130, 450, 150, 40);
        add.setBackground(new Color(25, 25, 112));
        add.setForeground(Color.WHITE);
        add.setFocusPainted(false);
        add.setOpaque(true);
        add.setBorderPainted(false);
        add.setFont(new Font("Tahoma", Font.BOLD, 14));
        add.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        add.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                add.setBackground(new Color(65, 65, 165));
            }
            public void mouseExited(MouseEvent e) {
                add.setBackground(new Color(25, 25, 112));
            }
        });
        mainPanel.add(add);

        cancel = new JButton("Cancel");
        cancel.addActionListener(this);
        cancel.setBounds(300, 450, 150, 40);
        cancel.setBackground(new Color(220, 50, 50));
        cancel.setForeground(Color.WHITE);
        cancel.setFocusPainted(false);
        cancel.setOpaque(true);
        cancel.setBorderPainted(false);
        cancel.setFont(new Font("Tahoma", Font.BOLD, 14));
        cancel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        cancel.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                cancel.setBackground(new Color(240, 70, 70));
            }
            public void mouseExited(MouseEvent e) {
                cancel.setBackground(new Color(220, 50, 50));
            }
        });
        mainPanel.add(cancel);
        
        // Image on right side
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/eleven.jpg"));
        Image i3 = i1.getImage().getScaledInstance(450, 280, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l15 = new JLabel(i2);
        l15.setBounds(500, 100, 450, 280);
        mainPanel.add(l15);
        
        // Make window draggable from title bar
        MouseAdapter ma = new MouseAdapter() {
            private Point initialClick;
            
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
            }
            
            public void mouseDragged(MouseEvent e) {
                int thisX = getLocation().x;
                int thisY = getLocation().y;
                int xMoved = e.getX() - initialClick.x;
                int yMoved = e.getY() - initialClick.y;
                setLocation(thisX + xMoved, thisY + yMoved);
            }
        };
        
        titleBar.addMouseListener(ma);
        titleBar.addMouseMotionListener(ma);
        
        // Ensure window is visible
        setVisible(true);
        toFront();
        requestFocus();
    }
    
    public void actionPerformed(ActionEvent ae) { 
        if (ae.getSource() == add) {
            if (!validateFields()) {
                return;
            }
            
            String name = tfname.getText().trim();
            String age = tfage.getText().trim();
            String gender = (String) gendercombo.getSelectedItem();
            String company = tfcompany.getText().trim();
            String model = tfmodel.getText().trim();
            String availability = (String) availablecombo.getSelectedItem();
            String location = tflocation.getText().trim();
            
            try {
                Conn conn = new Conn();
                String query = "INSERT INTO driver VALUES('" + name + "', '" + age + "', '" + 
                             gender + "','" + company + "', '" + model + "', '" + 
                             availability + "', '" + location + "')";
                conn.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "New Driver Successfully Added");
                setVisible(false);
            } catch (Exception e) {
                errorLabel.setText("Database error: " + e.getMessage());
                e.printStackTrace();
            }
        } else if (ae.getSource() == cancel) {
            dispose();
        }
    }
    
    private boolean validateFields() {
        String name = tfname.getText().trim();
        if (name.isEmpty()) {
            errorLabel.setText("Name cannot be empty");
            tfname.requestFocus();
            return false;
        }
        if (!name.matches("^[a-zA-Z\\s]{2,50}$")) {
            errorLabel.setText("Invalid name (only letters and spaces, 2-50 chars)");
            tfname.requestFocus();
            return false;
        }
        
        String ageStr = tfage.getText().trim();
        if (ageStr.isEmpty()) {
            errorLabel.setText("Age cannot be empty");
            tfage.requestFocus();
            return false;
        }
        try {
            int age = Integer.parseInt(ageStr);
            if (age < 18 || age > 70) {
                errorLabel.setText("Age must be between 18 and 70");
                tfage.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            errorLabel.setText("Age must be a valid number");
            tfage.requestFocus();
            return false;
        }
        
        String company = tfcompany.getText().trim();
        if (company.isEmpty()) {
            errorLabel.setText("Car company cannot be empty");
            tfcompany.requestFocus();
            return false;
        }
        if (!company.matches("^[a-zA-Z0-9\\s\\-&.]{2,50}$")) {
            errorLabel.setText("Invalid company name (2-50 chars)");
            tfcompany.requestFocus();
            return false;
        }
        
        String model = tfmodel.getText().trim();
        if (model.isEmpty()) {
            errorLabel.setText("Car model cannot be empty");
            tfmodel.requestFocus();
            return false;
        }
        if (!model.matches("^[a-zA-Z0-9\\s\\-.]{1,30}$")) {
            errorLabel.setText("Invalid model (1-30 chars)");
            tfmodel.requestFocus();
            return false;
        }
        
        String location = tflocation.getText().trim();
        if (location.isEmpty()) {
            errorLabel.setText("Location cannot be empty");
            tflocation.requestFocus();
            return false;
        }
        if (!location.matches("^[a-zA-Z\\s,]{2,100}$")) {
            errorLabel.setText("Invalid location (only letters, spaces and commas)");
            tflocation.requestFocus();
            return false;
        }
        
        errorLabel.setText("");
        return true;
    }

    public static void main(String[] args) {
        new AddDriver(null);
    }
}