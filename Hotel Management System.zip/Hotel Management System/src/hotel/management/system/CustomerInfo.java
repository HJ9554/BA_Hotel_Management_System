package hotel.management.system;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import java.sql.*;	
import javax.swing.*;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CustomerInfo extends JFrame {
    Connection conn = null;
    private JPanel contentPane;
    private JLabel lblId;
    private JLabel lblNewLabel;
    private JLabel lblGender;
    private JTable table;
    private JLabel lblCountry;
    private JLabel lblRoom;
    private JLabel lblStatus;
    private JLabel lblNewLabel_1;
    private int xMouse, yMouse;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CustomerInfo frame = new CustomerInfo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void close() {
        this.dispose();
    }

    /**
     * Create the frame.
     * @throws SQLException 
     */
    public CustomerInfo() throws SQLException {
        setUndecorated(true); // Remove default title bar
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(450, 100, 930, 700);
        
        // Create rounded border
        setBackground(new Color(0, 0, 0, 0));
        
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Dimension arcs = new Dimension(15, 15);
                int width = getWidth();
                int height = getHeight();
                Graphics2D graphics = (Graphics2D) g;
                graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Draw rounded border
                graphics.setColor(new Color(51, 102, 153));
                graphics.fillRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height);
                
                // Draw content area with different color
                graphics.setColor(new Color(240, 240, 240));
                graphics.fillRoundRect(2, 32, width-4, height-34, arcs.width, arcs.height);
            }
        };
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);
        
        // Custom title bar panel
        JPanel titleBarPanel = new JPanel();
        titleBarPanel.setBackground(new Color(51, 102, 153));
        titleBarPanel.setBounds(0, 0, 930, 40);
        titleBarPanel.setLayout(null);
        titleBarPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });
        titleBarPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                setLocation(x - xMouse, y - yMouse);
            }
        });
        contentPane.add(titleBarPanel);
        
        // Title label
        JLabel titleLabel = new JLabel("Customer Information");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(20, 5, 250, 30);
        titleBarPanel.add(titleLabel);
        
        // Close button
        JButton closeButton = new JButton("X");
        closeButton.setBounds(880, 5, 40, 30);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(new Color(51, 102, 153));
        closeButton.setBorder(BorderFactory.createEmptyBorder());
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(new Color(204, 0, 0));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(new Color(51, 102, 153));
            }
        });
        closeButton.addActionListener(e -> dispose());
        titleBarPanel.add(closeButton);
        
        // Main heading
        JLabel heading = new JLabel("Customer Info");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 24));
        heading.setBounds(370, 45, 200, 50);
        heading.setForeground(new Color(51, 102, 153));
        contentPane.add(heading);
        
        table = new JTable();
        table.setBounds(20, 120, 890, 400);
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(51, 102, 153));
        table.setSelectionForeground(Color.WHITE);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(25);
        contentPane.add(table);
        
        // Buttons
        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                    // Show loading indicator
                    btnLoadData.setText("Loading...");
                    btnLoadData.setEnabled(false);
                    
                    // Execute database operation in a separate thread to prevent UI freeze
                    SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
                        @Override
                        protected Void doInBackground() throws Exception {
                            try {
                                Conn c = new Conn();
                                String displayCustomersql = "select * from Customer";
                                ResultSet rs = c.s.executeQuery(displayCustomersql);
                                
                                // Check if result set is empty
                                if (!rs.isBeforeFirst()) {
                                    SwingUtilities.invokeLater(() -> {
                                        JOptionPane.showMessageDialog(contentPane, 
                                            "No customer data found!", 
                                            "Information", 
                                            JOptionPane.INFORMATION_MESSAGE);
                                    });
                                } else {
                                    SwingUtilities.invokeLater(() -> {
                                        table.setModel(DbUtils.resultSetToTableModel(rs));
                                    });
                                }
                            } catch (SQLException ex) {
                                SwingUtilities.invokeLater(() -> {
                                    JOptionPane.showMessageDialog(contentPane, 
                                        "Database error: " + ex.getMessage(), 
                                        "Error", 
                                        JOptionPane.ERROR_MESSAGE);
                                    ex.printStackTrace();
                                });
                            } catch (Exception ex) {
                                SwingUtilities.invokeLater(() -> {
                                    JOptionPane.showMessageDialog(contentPane, 
                                        "Unexpected error: " + ex.getMessage(), 
                                        "Error", 
                                        JOptionPane.ERROR_MESSAGE);
                                    ex.printStackTrace();
                                });
                            }
                            return null;
                        }

                        @Override
                        protected void done() {
                            // Reset button state
                            btnLoadData.setText("Load Data");
                            btnLoadData.setEnabled(true);
                        }
                    };
                    
                    worker.execute();
                    
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(contentPane, 
                        "Failed to initiate data loading: " + e.getMessage(), 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                    e.printStackTrace();
                    btnLoadData.setText("Load Data");
                    btnLoadData.setEnabled(true);
                }
            }
        });
        btnLoadData.setBounds(300, 570, 150, 40);
        btnLoadData.setBackground(new Color(51, 102, 153));
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLoadData.setBorder(BorderFactory.createEmptyBorder());
        btnLoadData.setOpaque(true);
        btnLoadData.setBorderPainted(false);
        contentPane.add(btnLoadData);
        
        JButton btnExit = new JButton("Back");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Reception().setVisible(true);
                setVisible(false);
            }
        });
        btnExit.setBounds(470, 570, 150, 40);
        btnExit.setBackground(new Color(51, 102, 153));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnExit.setBorder(BorderFactory.createEmptyBorder());
        btnExit.setOpaque(true);
        btnExit.setBorderPainted(false);
        contentPane.add(btnExit);
        
        // Column headers
        lblId = new JLabel("Document Type");
        lblId.setBounds(20, 100, 100, 14);
        lblId.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblId.setForeground(new Color(51, 102, 153));
        contentPane.add(lblId);
        
        JLabel l1 = new JLabel("Number");
        l1.setBounds(160, 100, 60, 14);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l1.setForeground(new Color(51, 102, 153));
        contentPane.add(l1);
        
        lblNewLabel = new JLabel("Name");
        lblNewLabel.setBounds(270, 100, 60, 14);
        lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblNewLabel.setForeground(new Color(51, 102, 153));
        contentPane.add(lblNewLabel);
        
        lblGender = new JLabel("Gender");
        lblGender.setBounds(360, 100, 60, 14);
        lblGender.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblGender.setForeground(new Color(51, 102, 153));
        contentPane.add(lblGender);
        
        lblCountry = new JLabel("Country");
        lblCountry.setBounds(480, 100, 60, 14);
        lblCountry.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCountry.setForeground(new Color(51, 102, 153));
        contentPane.add(lblCountry);
        
        lblRoom = new JLabel("Room");
        lblRoom.setBounds(600, 100, 60, 14);
        lblRoom.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRoom.setForeground(new Color(51, 102, 153));
        contentPane.add(lblRoom);
        
        lblStatus = new JLabel("Check-in Status");
        lblStatus.setBounds(690, 100, 100, 14);
        lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblStatus.setForeground(new Color(51, 102, 153));
        contentPane.add(lblStatus);
        
        lblNewLabel_1 = new JLabel("Deposit");
        lblNewLabel_1.setBounds(820, 100, 60, 14);
        lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblNewLabel_1.setForeground(new Color(51, 102, 153));
        contentPane.add(lblNewLabel_1);
        
        // Set location relative to null to center the window
        setLocationRelativeTo(null);
    }
}