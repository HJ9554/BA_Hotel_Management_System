package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import java.sql.*;
import java.awt.event.*;

public class Department extends JFrame {
    private JPanel contentPane;
    private JTable table;
    private JLabel lblDepartment, lblBudget;
    private int xMouse, yMouse;

    public Department() {
        // ===== Window Configuration =====
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(600, 200, 730, 500);
        
        // ===== Content Panel Setup =====
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Force proper rendering of components
                getComponents()[0].repaint();
            }
        };
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(Color.WHITE);
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // ===== Custom Title Bar =====
        JPanel titleBarPanel = new JPanel();
        titleBarPanel.setBackground(new Color(0, 120, 215));
        titleBarPanel.setBounds(0, 0, 730, 30);
        titleBarPanel.setLayout(null);
        contentPane.add(titleBarPanel);

        // Title Label
        JLabel titleLabel = new JLabel("Department Information");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setBounds(10, 5, 200, 20);
        titleBarPanel.add(titleLabel);

        // Close Button (X)
        JLabel closeLabel = new JLabel("X");
        closeLabel.setForeground(Color.WHITE);
        closeLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        closeLabel.setBounds(700, 0, 30, 30);
        closeLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                closeLabel.setBackground(Color.RED);
                closeLabel.setOpaque(true);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeLabel.setBackground(null);
                closeLabel.setOpaque(false);
            }
        });
        titleBarPanel.add(closeLabel);

        // ===== Mouse Drag Functionality =====
        titleBarPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });
        titleBarPanel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                setLocation(x - xMouse, y - yMouse);
            }
        });

        // ===== Table Setup =====
        table = new JTable();
        table.setBounds(10, 70, 700, 300);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.setRowHeight(25);
        table.setTableHeader(null);
        contentPane.add(table);

        // ===== "Load Data" Button =====
        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.addActionListener(e -> {
            try {
                Conn c = new Conn();
                String sql = "SELECT * FROM Department";
                ResultSet rs = c.s.executeQuery(sql);
                
                if (!rs.isBeforeFirst()) {
                    JOptionPane.showMessageDialog(null, "No department data found!", "Information", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    table.setModel(DbUtils.resultSetToTableModel(rs));
                    table.setTableHeader(null);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error loading data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        btnLoadData.setBounds(170, 410, 120, 30);
        btnLoadData.setBackground(new Color(0, 120, 215));
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.setFocusPainted(false);
        btnLoadData.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnLoadData.setOpaque(true);
        btnLoadData.setBorderPainted(false);
        contentPane.add(btnLoadData);

        // ===== "Back" Button =====
        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(e -> {
            // Create new Reception instance before disposing this one
            Reception reception = new Reception();
            reception.setVisible(true);
            dispose(); // Properly close this window
        });
        btnBack.setBounds(400, 410, 120, 30);
        btnBack.setBackground(new Color(220, 53, 69));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBack.setOpaque(true);
        btnBack.setBorderPainted(false);
        contentPane.add(btnBack);

        // ===== Labels for Table Headers =====
        lblDepartment = new JLabel("Department");
        lblDepartment.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblDepartment.setBounds(145, 45, 105, 14);
        contentPane.add(lblDepartment);

        lblBudget = new JLabel("Budget");
        lblBudget.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblBudget.setBounds(431, 45, 75, 14);
        contentPane.add(lblBudget);

        // ===== Final Focus and Visibility Fixes =====
        // Use WindowListener to ensure proper focus
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                EventQueue.invokeLater(() -> {
                    toFront();
                    requestFocus();
                    repaint();
                });
            }
        });
    }

    // Main method for testing
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            Department frame = new Department();
            frame.setVisible(true);
        });
    }
}