package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.sql.*;

public class Reception extends JFrame {

    private Point initialClick;

    public Reception() {
        initializeWindow();
        createContent();
        setupWindowManagement();
    }

    private void initializeWindow() {
        setUndecorated(true);
        setTitle("Reception");
        setSize(850, 570);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createContent() {
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/reception.jpg"));
                g.drawImage(icon.getImage(), 200, 40, 650, 550, this);
            }
        };
        mainPanel.setBackground(Color.WHITE);
        setContentPane(mainPanel);

        mainPanel.add(createTitleBar(), BorderLayout.NORTH);
        mainPanel.add(createButtonPanel(), BorderLayout.WEST);
    }

    private JPanel createTitleBar() {
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(70, 130, 180));
        titlePanel.setPreferredSize(new Dimension(getWidth(), 40));

        JLabel titleLabel = new JLabel("  Reception");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        titlePanel.add(titleLabel, BorderLayout.WEST);

        // Modified close button action
        JButton closeButton = new JButton("×");
        closeButton.setFont(new Font("Arial", Font.BOLD, 18));
        closeButton.setContentAreaFilled(false);
        closeButton.setBorderPainted(false);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> dispose()); // Changed to only close this window
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(new Color(255, 100, 100));
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(Color.WHITE);
            }
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(closeButton);
        titlePanel.add(buttonPanel, BorderLayout.EAST);

        titlePanel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
            }
        });

        titlePanel.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int thisX = getLocation().x;
                int thisY = getLocation().y;
                int xMoved = e.getX() - initialClick.x;
                int yMoved = e.getY() - initialClick.y;
                setLocation(thisX + xMoved, thisY + yMoved);
            }
        });

        return titlePanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setPreferredSize(new Dimension(200, 530));
        buttonPanel.setBackground(new Color(255, 255, 255));
        buttonPanel.setLayout(new GridLayout(12, 1, 0, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        String[] buttonLabels = {
            "New Customer Form", "Room", "Department", "All Employee Info",
            "Customer Info", "Manager Info", "Check Out", "Update Check Status",
            "Update Room Status", "Pick up Service", "Search Room", "Log Out"
        };

        for (String label : buttonLabels) {
            JButton button = createStyledButton(label);
            button.addActionListener(createButtonAction(label));
            buttonPanel.add(button);
        }

        return buttonPanel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
                
                g2.setColor(new Color(30, 144, 255));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
                
                g2.setColor(getForeground());
                FontMetrics fm = g2.getFontMetrics();
                Rectangle2D r = fm.getStringBounds(getText(), g2);
                int x = (this.getWidth() - (int) r.getWidth()) / 2;
                int y = (this.getHeight() - (int) r.getHeight()) / 2 + fm.getAscent();
                g2.drawString(getText(), x, y);
                
                g2.dispose();
            }
        };

        button.setContentAreaFilled(true);
        button.setFocusPainted(true);
        button.setOpaque(true);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(70, 130, 180));
        button.setFont(new Font("Tahoma", Font.BOLD, 12));
        button.setPreferredSize(new Dimension(180, 40));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(30, 144, 255));
                button.repaint();
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(70, 130, 180));
                button.repaint();
            }
            public void mousePressed(MouseEvent e) {
                button.setBackground(new Color(0, 0, 139));
                button.repaint();
            }
            public void mouseReleased(MouseEvent e) {
                button.setBackground(new Color(70, 130, 180));
                button.repaint();
            }
        });

        return button;
    }

    private ActionListener createButtonAction(String buttonLabel) {
        return e -> {
            try {
                setVisible(false);
                
                switch(buttonLabel) {
                    case "New Customer Form":
                        new AddCustomer().setVisible(true);
                        break;
                    case "Room":
                        new Room().setVisible(true);
                        break;
                    case "Department":
                        new Department().setVisible(true);
                        break;
                    case "All Employee Info":
                        new EmployeeInfo().setVisible(true);
                        break;
                    case "Customer Info":
                        new CustomerInfo().setVisible(true);
                        break;
                    case "Manager Info":
                        new ManagerInfo().setVisible(true);
                        break;
                    case "Check Out":
                        new CheckOut().setVisible(true);
                        break;
                    case "Update Check Status":
                        new UpdateCheck().setVisible(true);
                        break;
                    case "Update Room Status":
                        new UpdateRoom().setVisible(true);
                        break;
                    case "Pick up Service":
                        new Pickup().setVisible(true);
                        break;
                    case "Search Room":
                        new SearchRoom().setVisible(true);
                        break;
                    case "Log Out":
                        dispose(); // Only closes this window
                        break;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                setVisible(true);
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        };
    }

    private void setupWindowManagement() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose(); // Ensure proper cleanup
            }
        });
    }

    public static void showReception() {
        EventQueue.invokeLater(() -> {
            Reception reception = new Reception();
            reception.setVisible(true);
            
            SwingUtilities.invokeLater(() -> {
                reception.toFront();
                reception.requestFocus();
                reception.repaint();
            });
        });
    }
}