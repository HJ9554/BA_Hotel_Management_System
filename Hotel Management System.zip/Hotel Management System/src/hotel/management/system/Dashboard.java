package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Dashboard extends JFrame implements ActionListener {
    
    Dashboard() {
        super("HOTEL MANAGEMENT SYSTEM");
        setUndecorated(true);
        setBounds(0, 0, 1540, 980);
        getContentPane().setBackground(Color.WHITE);
        
        // Main container with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);
        
        // Header panel that will contain both title bar and menu bar
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        // Custom title bar - placed NORTH in header panel
        JPanel titleBar = new JPanel(new BorderLayout());
        titleBar.setBackground(new Color(70, 130, 180)); // Steel blue
        titleBar.setPreferredSize(new Dimension(1540, 40));
        
        // Title label
        JLabel titleLabel = new JLabel("HOTEL MANAGEMENT SYSTEM");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        titleBar.add(titleLabel, BorderLayout.WEST);
        
        // Close button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setOpaque(false);
        
        JButton closeButton = new JButton("×");
        closeButton.setFont(new Font("Arial", Font.BOLD, 24));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(new Color(200, 50, 50));
        closeButton.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        closeButton.addActionListener(e -> System.exit(0));
        
        // Hover effects for close button
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(new Color(220, 80, 80));
                closeButton.setForeground(Color.WHITE);
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(new Color(200, 50, 50));
                closeButton.setForeground(Color.WHITE);
            }
        });
        
        buttonPanel.add(closeButton);
        titleBar.add(buttonPanel, BorderLayout.EAST);
        
        // Add title bar to header panel
        headerPanel.add(titleBar, BorderLayout.NORTH);
        
        // Modern menu bar - placed CENTER in header panel (below title bar)
        JMenuBar mb = new JMenuBar();
        mb.setBackground(new Color(240, 240, 240)); // Light gray background
        mb.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200)));
        
        // Custom menu styling
        UIManager.put("MenuBar.background", new Color(240, 240, 240));
        UIManager.put("Menu.background", new Color(240, 240, 240));
        UIManager.put("Menu.foreground", new Color(70, 70, 70));
        UIManager.put("Menu.font", new Font("Segoe UI", Font.BOLD, 14));
        UIManager.put("Menu.border", BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        // Menu item styling
        UIManager.put("MenuItem.background", Color.WHITE);
        UIManager.put("MenuItem.foreground", new Color(70, 70, 70));
        UIManager.put("MenuItem.font", new Font("Segoe UI", Font.PLAIN, 13));
        UIManager.put("MenuItem.border", BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        // Hotel Management Menu (Green theme)
        JMenu hotel = new JMenu("HOTEL MANAGEMENT");
        hotel.setBackground(new Color(46, 125, 50)); // Dark green
        hotel.setForeground(Color.WHITE);
        hotel.setOpaque(true);
        hotel.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        mb.add(hotel);
        
        JMenuItem reception = new JMenuItem("RECEPTION");
        reception.addActionListener(this);
        reception.setBackground(Color.WHITE);
        reception.setForeground(new Color(46, 125, 50)); // Dark green text
        hotel.add(reception);
        
        // Admin Menu (Purple theme)
        JMenu admin = new JMenu("ADMIN");
        admin.setBackground(new Color(123, 31, 162)); // Dark purple
        admin.setForeground(Color.WHITE);
        admin.setOpaque(true);
        admin.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        mb.add(admin);
        
        JMenuItem addemployee = new JMenuItem("ADD EMPLOYEE");
        addemployee.addActionListener(this);
        addemployee.setBackground(Color.WHITE);
        addemployee.setForeground(new Color(123, 31, 162)); // Purple text
        admin.add(addemployee);

        JMenuItem addrooms = new JMenuItem("ADD ROOMS");
        addrooms.addActionListener(this);
        addrooms.setBackground(Color.WHITE);
        addrooms.setForeground(new Color(123, 31, 162)); // Purple text
        admin.add(addrooms);
        
        JMenuItem adddrivers = new JMenuItem("ADD DRIVERS");
        adddrivers.addActionListener(this);
        adddrivers.setBackground(Color.WHITE);
        adddrivers.setForeground(new Color(123, 31, 162)); // Purple text
        admin.add(adddrivers);
        
        // Add hover effects to menu items
        for (int i = 0; i < mb.getMenuCount(); i++) {
            JMenu menu = mb.getMenu(i);
            
            // Different hover colors for different menus
            Color hoverColor;
            if (menu.getText().equals("HOTEL MANAGEMENT")) {
                hoverColor = new Color(76, 175, 80); // Light green
            } else {
                hoverColor = new Color(156, 39, 176); // Light purple
            }
            
            final Color finalHoverColor = hoverColor;
            
            menu.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    menu.setBackground(finalHoverColor);
                    menu.setForeground(Color.WHITE);
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    if (menu.getText().equals("HOTEL MANAGEMENT")) {
                        menu.setBackground(new Color(46, 125, 50));
                    } else {
                        menu.setBackground(new Color(123, 31, 162));
                    }
                    menu.setForeground(Color.WHITE);
                }
            });
            
            for (int j = 0; j < menu.getItemCount(); j++) {
                JMenuItem item = menu.getItem(j);
                if (item != null) {
                    item.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseEntered(MouseEvent e) {
                            item.setBackground(finalHoverColor);
                            item.setForeground(Color.WHITE);
                        }
                        @Override
                        public void mouseExited(MouseEvent e) {
                            item.setBackground(Color.WHITE);
                            if (menu.getText().equals("HOTEL MANAGEMENT")) {
                                item.setForeground(new Color(46, 125, 50));
                            } else {
                                item.setForeground(new Color(123, 31, 162));
                            }
                        }
                    });
                }
            }
        }
        
        // Add menu bar to header panel
        headerPanel.add(mb, BorderLayout.CENTER);
        
        // Add header panel to main panel (NORTH)
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Main content
        JPanel contentPanel = new JPanel(null);
        contentPanel.setBackground(Color.WHITE);
        
        // Background image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1600, 960, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2); 
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1600, 960);
        contentPanel.add(image);
        
        // Welcome text with modern styling
        JLabel text = new JLabel("THE TAJ GROUP WELCOMES YOU");
        text.setForeground(new Color(220, 20, 60)); // Crimson red
        text.setFont(new Font("Segoe UI", Font.BOLD, 48));
        text.setBounds(400, 30, 1000, 85);
        image.add(text);
        
        // Add content panel to main panel
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Make window draggable via title bar
        MouseAdapter ma = new MouseAdapter() {
            private Point initialClick;
            
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
                getComponentAt(initialClick);
            }
            
            public void mouseDragged(MouseEvent e) {
                int thisX = getLocation().x;
                int thisY = getLocation().y;
                int xMoved = e.getX() - initialClick.x;
                int yMoved = e.getY() - initialClick.y;
                setLocation(thisX + xMoved, thisY + yMoved);
            }
        };
        
        titleBar.addMouseListener(ma);
        titleBar.addMouseMotionListener(ma);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getActionCommand().equals("ADD EMPLOYEE")) {
            new AddEmployee();
        } else if (ae.getActionCommand().equals("ADD ROOMS")) {
            new AddRooms();
        } else if (ae.getActionCommand().equals("ADD DRIVERS")) {
            new AddDriver(null);
        } else if (ae.getActionCommand().equals("RECEPTION")) {
              Reception.showReception();
      }
        
    }

    public static void main(String[] args) {
        new Dashboard();
    }
}