package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

public class HotelManagementSystem extends JFrame implements ActionListener {

    JLabel l1;
    JLabel lid;
    JButton b1;
    Timer shadowTimer;
    Timer blinkTimer;
    float shadowOpacity = 0f;
    boolean increasing = true;
    JPanel gradientPanel;

    public HotelManagementSystem() {
        // Initialize frame properties
        setTitle("Hotel Management System");
        setSize(1118, 730);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);
        setLayout(null);
        getContentPane().setBackground(new Color(20, 30, 50));

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Main image label
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/front.jpg"));
        Image i3 = i1.getImage().getScaledInstance(1100, 730, Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(i3);
        l1 = new JLabel(i2);
        l1.setBounds(0, 0, 1106, 730);
        add(l1);

        // System title label - Modified size and position
        lid = new JLabel("HOTEL MANAGEMENT SYSTEM");
        lid.setBounds(30, 580, 1200, 150);  // Increased height and moved up
        lid.setFont(new Font("Segoe UI", Font.BOLD, 50));  // Increased font size
        
        // Gradient panel for text
        gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                
                // Ensure shadowOpacity stays within valid range (0-1)
                float clampedShadowOpacity = Math.max(0f, Math.min(1f, shadowOpacity));
                g2d.setColor(new Color(0, 0, 0, clampedShadowOpacity));
                g2d.drawString(lid.getText(), 5, 110);  // Adjusted y position
                
                // Draw main text with gradient
                GradientPaint gradient = new GradientPaint(0, 0, new Color(100, 200, 255), 
                                             0, 120, new Color(50, 150, 250));  // Adjusted gradient
                g2d.setPaint(gradient);
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 50));  // Set font here too
                g2d.drawString(lid.getText(), 0, 100);  // Adjusted y position
            }
        };
        gradientPanel.setBounds(lid.getBounds());
        gradientPanel.setOpaque(false);
        l1.add(gradientPanel);

        // Next button
        b1 = new JButton("NEXT");
        b1.setBounds(870, 630, 180, 60);
        b1.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b1.setForeground(new Color(50, 50, 50));
        b1.setBackground(new Color(255, 255, 255, 200));
        b1.setFocusPainted(false);
        b1.setBorder(new CompoundBorder(
            new LineBorder(new Color(200, 200, 255), 2),
            new EmptyBorder(10, 25, 10, 25)
        ));
        
        // Hover effects
        b1.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                b1.setBackground(new Color(255, 255, 255));
                b1.setForeground(new Color(30, 100, 200));
            }
            public void mouseExited(MouseEvent e) {
                b1.setBackground(new Color(255, 255, 255, 200));
                b1.setForeground(new Color(50, 50, 50));
            }
        });

        l1.add(b1);
        b1.addActionListener(this);
        
        // Shadow timer for pulsing effect
        shadowTimer = new Timer(50, e -> {
            if (increasing) {
                shadowOpacity += 0.05f;
                if (shadowOpacity >= 0.8f) increasing = false;
            } else {
                shadowOpacity -= 0.05f;
                if (shadowOpacity <= 0f) increasing = true;
            }
            gradientPanel.repaint();
        });

        // Blink timer for blinking effect
        blinkTimer = new Timer(800, e -> {
            gradientPanel.setVisible(!gradientPanel.isVisible());
        });

        // Title bar
        JPanel titleBar = new JPanel();
        titleBar.setBounds(0, 0, 1118, 30);
        titleBar.setBackground(new Color(20, 30, 50, 200));
        titleBar.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("  Hotel Management System");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        // Close button
        JButton closeButton = new JButton("X");
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(Color.RED);
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(Color.WHITE);
            }
        });
        closeButton.addActionListener(e -> System.exit(0));
        
        titleBar.add(titleLabel, BorderLayout.WEST);
        titleBar.add(closeButton, BorderLayout.EAST);
        add(titleBar);
    }

    public void actionPerformed(ActionEvent ae) {
        shadowTimer.stop();
        blinkTimer.stop();
        new Login().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            HotelManagementSystem window = new HotelManagementSystem();
            window.setVisible(true);
            window.shadowTimer.start();
            window.blinkTimer.start();
        });
    }
}