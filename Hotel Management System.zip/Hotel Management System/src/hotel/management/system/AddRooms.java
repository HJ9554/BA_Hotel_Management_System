package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.regex.*;

public class AddRooms extends JFrame implements ActionListener {
    
    JButton add, cancel;
    JTextField tfroom, tfprice;
    JComboBox<String> availablecombo, cleancombo, typecombo;  
    JLabel errorLabel;
    private Point lastPosition;
    
    AddRooms() {
        // Window setup
        setUndecorated(true);
        getContentPane().setBackground(new Color(240, 240, 240));
        setBounds(330, 200, 940, 470);
        
        // Custom title bar
        JPanel titleBar = createTitleBar();
        
        // Main content panel
        JPanel mainPanel = createMainPanel();
        
        // Add components to frame
        setLayout(new BorderLayout());
        add(titleBar, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        
        setVisible(true);
        toFront();
        requestFocus();
    }
    
    private JPanel createTitleBar() {
        JPanel titleBar = new JPanel();
        titleBar.setBackground(new Color(25, 25, 112));
        titleBar.setLayout(new BorderLayout());
        titleBar.setPreferredSize(new Dimension(getWidth(), 40));

        JLabel title = new JLabel("  Add Rooms", SwingConstants.LEFT);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        
        JButton closeButton = new JButton("×");
        closeButton.setContentAreaFilled(false);
        closeButton.setBorderPainted(false);
        closeButton.setFocusPainted(false);
        closeButton.setBackground(new Color(25, 25, 112));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Arial", Font.BOLD, 20));
        closeButton.setOpaque(true);
        closeButton.addActionListener(e -> dispose());
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(new Color(204, 0, 0));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(new Color(25, 25, 112));
            }
        });

        titleBar.add(title, BorderLayout.WEST);
        titleBar.add(closeButton, BorderLayout.EAST);

        // Window dragging functionality
        titleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastPosition = e.getPoint();
            }
        });
        
        titleBar.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point currCoords = e.getLocationOnScreen();
                setLocation(currCoords.x - lastPosition.x, currCoords.y - lastPosition.y);
            }
        });

        return titleBar;
    }
    
    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel heading = new JLabel("Add Rooms");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 18));
        heading.setForeground(new Color(25, 25, 112));
        heading.setBounds(150, 20, 200, 20);
        mainPanel.add(heading);
        
        // Error label
        errorLabel = new JLabel("");
        errorLabel.setForeground(Color.RED);
        errorLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        errorLabel.setBounds(200, 360, 400, 30);
        mainPanel.add(errorLabel);
        
        // Room Number
        addLabelAndField(mainPanel, "Room Number", 60, 60, tfroom = new JTextField());
        
        // Availability
        addComboBox(mainPanel, "Availability", 60, 110, 
                   availablecombo = new JComboBox<>(new String[]{"Available", "Occupied"}));
        
        // Cleaning Status
        addComboBox(mainPanel, "Cleaning Status", 60, 160, 
                   cleancombo = new JComboBox<>(new String[]{"Cleaned", "Dirty"}));
        
        // Price
        addLabelAndField(mainPanel, "Price", 60, 210, tfprice = new JTextField());
        
        // Bed Type
        addComboBox(mainPanel, "Bed Type", 60, 260, 
                   typecombo = new JComboBox<>(new String[]{"Single Bed", "Double Bed"}));
        
        // Fixed: Buttons with proper visibility
        add = new JButton("Add Room");
        add.setBounds(60, 330, 130, 35);
        add.setBackground(new Color(25, 25, 112));
        add.setForeground(Color.WHITE);
        add.setFont(new Font("Segoe UI", Font.BOLD, 14));
        add.setBorder(BorderFactory.createLineBorder(new Color(25, 25, 112), 2));
        add.setBorderPainted(false);
        add.setFocusPainted(false);
        add.setOpaque(true);
        add.setContentAreaFilled(true);
        add.addActionListener(this);
        mainPanel.add(add);

        cancel = new JButton("Cancel");
        cancel.setBounds(220, 330, 130, 35);
        cancel.setBackground(new Color(25, 25, 112));
        cancel.setForeground(Color.WHITE);
        cancel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cancel.setBorder(BorderFactory.createLineBorder(new Color(25, 25, 112), 2));
        cancel.setBorderPainted(false);
        cancel.setFocusPainted(false);
        cancel.setOpaque(true);
        cancel.setContentAreaFilled(true);
        cancel.addActionListener(this);
        mainPanel.add(cancel);
        
        // Hover effects for both buttons
        add.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                add.setBackground(new Color(65, 105, 225));
                add.setBorder(BorderFactory.createLineBorder(new Color(65, 105, 225), 2));
            }
            public void mouseExited(MouseEvent e) {
                add.setBackground(new Color(25, 25, 112));
                add.setBorder(BorderFactory.createLineBorder(new Color(25, 25, 112), 2));
            }
        });
        
        cancel.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                cancel.setBackground(new Color(65, 105, 225));
                cancel.setBorder(BorderFactory.createLineBorder(new Color(65, 105, 225), 2));
            }
            public void mouseExited(MouseEvent e) {
                cancel.setBackground(new Color(25, 25, 112));
                cancel.setBorder(BorderFactory.createLineBorder(new Color(25, 25, 112), 2));
            }
        });
        
        // Image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/twelve.jpg"));
        Image i3 = i1.getImage().getScaledInstance(450, 300, Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel image = new JLabel(i2);
        image.setBounds(450, 60, 450, 300);
        mainPanel.add(image);       
        
        return mainPanel;
    }
    
    private void addLabelAndField(JPanel panel, String labelText, int x, int y, JTextField textField) {
        JLabel label = new JLabel(labelText);
        label.setForeground(new Color(25, 25, 112));
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setBounds(x, y, 120, 30);
        panel.add(label);
        
        textField.setBounds(200, y, 150, 30);
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        panel.add(textField);
    }
    
    private void addComboBox(JPanel panel, String labelText, int x, int y, JComboBox<String> comboBox) {
        JLabel label = new JLabel(labelText);
        label.setForeground(new Color(25, 25, 112));
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setBounds(x, y, 120, 30);
        panel.add(label);
        
        comboBox.setBounds(200, y, 150, 30);
        comboBox.setBackground(Color.WHITE);
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panel.add(comboBox);
    }
    
    public void actionPerformed(ActionEvent ae) { 
        if (ae.getSource() == add) {
            if (!validateFields()) {
                return;
            }
            
            String roomnumber = tfroom.getText().trim();
            String availability = (String) availablecombo.getSelectedItem();
            String status = (String) cleancombo.getSelectedItem();
            String price = tfprice.getText().trim();
            String type = (String) typecombo.getSelectedItem();

            try {
                Conn conn = new Conn();
                String query = String.format("INSERT INTO room VALUES('%s', '%s', '%s', '%s', '%s')",
                                          roomnumber, availability, status, price, type);
                conn.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "New Room Successfully Added");
                dispose();
            } catch (Exception e) {
                errorLabel.setText("Database error: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            dispose();
        }
    }
    
    private boolean validateFields() {
        // Room Number validation
        String roomnumber = tfroom.getText().trim();
        if (roomnumber.isEmpty()) {
            showError("Room number cannot be empty", tfroom);
            return false;
        }
        if (!roomnumber.matches("^[a-zA-Z0-9]{3,10}$")) {
            showError("Room number must be 3-10 alphanumeric chars", tfroom);
            return false;
        }
        
        // Price validation
        String priceStr = tfprice.getText().trim();
        if (priceStr.isEmpty()) {
            showError("Price cannot be empty", tfprice);
            return false;
        }
        try {
            double price = Double.parseDouble(priceStr);
            if (price <= 0) {
                showError("Price must be positive", tfprice);
                return false;
            }
            tfprice.setText(String.format("%.2f", price));
        } catch (NumberFormatException e) {
            showError("Price must be a valid number", tfprice);
            return false;
        }
        
        errorLabel.setText("");
        return true;
    }

    private void showError(String message, Component component) {
        errorLabel.setText(message);
        component.requestFocus();
    }

    public static void main(String[] args) {       
            new AddRooms();
        
    }
}