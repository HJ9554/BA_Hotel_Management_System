package hotel.management.system;

import java.awt.*;
import java.sql.*;
import java.util.Date;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.border.LineBorder;

public class CheckOut extends JFrame implements ActionListener {

    private Choice ccustomer;
    private JLabel lblroomnumber, lblcheckintime, lblcheckouttime;
    private JButton checkout, back, l2;
    private JPanel contentPane, titlePanel;
    private JLabel titleLabel;
    private JButton closeButton;
    private int mouseX, mouseY;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CheckOut frame = new CheckOut();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void close() {
        this.dispose();
    }

    public CheckOut() throws SQLException {
        initComponents();
        loadCustomerIDs();
    }

    private void initComponents() {
        setUndecorated(true); // Remove default title bar
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(300, 200, 800, 400);
        
        contentPane = new JPanel();
        contentPane.setBorder(new LineBorder(new Color(0, 120, 215), 2));
        contentPane.setLayout(null);
        setContentPane(contentPane);
        
        // Custom Title Bar
        titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 120, 215));
        titlePanel.setBounds(0, 0, 800, 40);
        titlePanel.setLayout(null);
        contentPane.add(titlePanel);
        
        titleLabel = new JLabel("Check Out Guest");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(10, 5, 200, 30);
        titlePanel.add(titleLabel);
        
        closeButton = new JButton("×");
        closeButton.setFont(new Font("Arial", Font.BOLD, 18));
        closeButton.setBounds(760, 0, 40, 40);
        closeButton.setBackground(new Color(25, 25, 112));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBorderPainted(false);
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 15));
        closeButton.addActionListener(e -> close());
        
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(Color.RED);
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(Color.WHITE);
            }
        });

        
        titlePanel.add(closeButton);
        
        // Add mouse listener for window dragging
        titlePanel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });
        
        titlePanel.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });
        
        setVisible(true);
        toFront();
        requestFocus();

        JLabel lblid = new JLabel("Customer ID:");
        lblid.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblid.setBounds(30, 60, 100, 30);
        contentPane.add(lblid);

        ccustomer = new Choice();
        ccustomer.setFont(new Font("Tahoma", Font.PLAIN, 14));
        ccustomer.setBounds(150, 60, 150, 25);
        contentPane.add(ccustomer);

        JLabel lblroom = new JLabel("Room Number:");
        lblroom.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblroom.setBounds(30, 110, 100, 30);
        contentPane.add(lblroom);

        lblroomnumber = new JLabel();
        lblroomnumber.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblroomnumber.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lblroomnumber.setBounds(150, 110, 150, 25);
        contentPane.add(lblroomnumber);

        JLabel lblcheckin = new JLabel("Check-in Time:");
        lblcheckin.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblcheckin.setBounds(30, 160, 100, 30);
        contentPane.add(lblcheckin);

        lblcheckintime = new JLabel();
        lblcheckintime.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblcheckintime.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lblcheckintime.setBounds(150, 160, 200, 25);
        contentPane.add(lblcheckintime);

        JLabel lblcheckout = new JLabel("Check-out Time:");
        lblcheckout.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblcheckout.setBounds(30, 210, 120, 30);
        contentPane.add(lblcheckout);

        Date date = new Date();
        lblcheckouttime = new JLabel("" + date);
        lblcheckouttime.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblcheckouttime.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lblcheckouttime.setBounds(150, 210, 200, 25);
        contentPane.add(lblcheckouttime);

        checkout = new JButton("Check Out");
        checkout.setFont(new Font("Tahoma", Font.BOLD, 14));
        checkout.setBackground(new Color(0, 120, 215));
        checkout.setForeground(Color.WHITE);
        checkout.setBounds(30, 280, 150, 35);
        checkout.setOpaque(true);
        checkout.setBorderPainted(false);
        checkout.addActionListener(this);
        contentPane.add(checkout);

        back = new JButton("Back");
        back.setFont(new Font("Tahoma", Font.BOLD, 14));
        back.setBackground(new Color(220, 50, 50));
        back.setForeground(Color.WHITE);
        back.setBounds(200, 280, 150, 35);
        back.setOpaque(true);
        back.setBorderPainted(false);
        back.addActionListener(this);
        contentPane.add(back);

        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/tick.png"));
        Image i5 = i4.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);

        l2 = new JButton(i6);
        l2.setBackground(Color.WHITE);
        l2.setBorder(BorderFactory.createEmptyBorder());
        l2.setBounds(310, 60, 30, 30);
        l2.setToolTipText("Load customer details");
        l2.addActionListener(this);
        contentPane.add(l2);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/sixth.jpg"));
        Image i3 = i1.getImage().getScaledInstance(410, 290, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l1 = new JLabel(i2);
        l1.setBounds(390, 50, 400, 250);
        contentPane.add(l1);
    }

    private void loadCustomerIDs() {
        try {
            Conn c = new Conn();
            ccustomer.removeAll();
            ResultSet rs = c.s.executeQuery("SELECT DISTINCT number FROM customer");
            while (rs.next()) {
                ccustomer.add(rs.getString("number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading customer data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadCustomerDetails() {
        String selectedCustomer = ccustomer.getSelectedItem();
        if (selectedCustomer == null) {
            JOptionPane.showMessageDialog(this, "Please select a customer first.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT room, checkintime FROM customer WHERE number = '" + selectedCustomer + "'");
            if (rs.next()) {
                lblroomnumber.setText(rs.getString("room"));
                lblcheckintime.setText(rs.getString("checkintime"));
            } else {
                JOptionPane.showMessageDialog(this, "Customer details not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading customer details.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == checkout) {
            if (ccustomer.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Please select a customer first.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (lblroomnumber.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please load customer details first.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this, 
                    "Confirm check out for customer " + ccustomer.getSelectedItem() + " from room " + lblroomnumber.getText() + "?",
                    "Confirm Check Out", JOptionPane.YES_NO_OPTION);
            
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            String query1 = "DELETE FROM customer WHERE number = '" + ccustomer.getSelectedItem() + "'";
            String query2 = "UPDATE room SET availability = 'Available' WHERE roomnumber = '" + lblroomnumber.getText() + "'";

            try {
                Conn c = new Conn();
                c.s.executeUpdate(query1);
                c.s.executeUpdate(query2);

                JOptionPane.showMessageDialog(this, "Checkout completed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                close();
                new Reception().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error during checkout.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } else if (ae.getSource() == l2) {
            loadCustomerDetails();
        } else {
            close();
            new Reception().setVisible(true);
        }
    }
}