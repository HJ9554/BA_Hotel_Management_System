package hotel.management.system;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Pickup extends JFrame {
    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private JPanel contentPane;
    private JTable table;
    Choice c1;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Pickup frame = new Pickup();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void close() {
        this.dispose();
    }

    public Pickup() throws SQLException {
        // Remove default title bar
        setUndecorated(true);
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(530, 200, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // Custom Title Bar Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(0, 120, 215));
        titlePanel.setBounds(0, 0, 800, 40);
        titlePanel.setLayout(null);
        contentPane.add(titlePanel);
        
        // Title Label
        JLabel titleLabel = new JLabel("Pick Up Service");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(10, 5, 200, 30);
        titlePanel.add(titleLabel);
        
        // Close Button
        JButton closeButton = new JButton("X");
        closeButton.setBounds(760, 5, 30, 30);
        closeButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(new Color(0, 120, 215));
        closeButton.setBorder(BorderFactory.createEmptyBorder());
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(Color.RED);
                
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(new Color(0, 120, 215));
                
            }
        });
        closeButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        titlePanel.add(closeButton);
        
        // Main content
        JLabel lblTypeOfCar = new JLabel("Type of Car:");
        lblTypeOfCar.setBounds(32, 60, 89, 20);
        lblTypeOfCar.setFont(new Font("Tahoma", Font.PLAIN, 14));
        contentPane.add(lblTypeOfCar);

        c1 = new Choice();
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from driver");
            while(rs.next()) {
                c1.add(rs.getString("company"));    
            }
        } catch(Exception e) { }
        c1.setBounds(130, 60, 200, 25);
        c1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        contentPane.add(c1);

        // Table headers with improved styling
        JLabel lblInfo = new JLabel("Name");
        lblInfo.setBounds(24, 160, 100, 20);
        lblInfo.setFont(new Font("Tahoma", Font.BOLD, 14));
        contentPane.add(lblInfo);
        
        JButton btnRegister = new JButton("Display");
        btnRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                String SQL = "select * from driver where company = '"+c1.getSelectedItem()+"'";
                try {
                    Conn c = new Conn();
                    rs = c.s.executeQuery(SQL);
                    table.setModel(DbUtils.resultSetToTableModel(rs));
                    table.setTableHeader(null);
                } catch (SQLException ss) {
                    ss.printStackTrace();
                }
            }
        });
        btnRegister.setBounds(200, 500, 120, 30);
        btnRegister.setBackground(new Color(0, 120, 215));
        btnRegister.setForeground(Color.WHITE);
        btnRegister.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnRegister.setOpaque(true);
        btnRegister.setBorderPainted(false);
        btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(btnRegister);
        
        JButton btnExit = new JButton("Back");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                new Reception().setVisible(true);
                setVisible(false);
            }
        });
        btnExit.setBounds(420, 500, 120, 30);
        btnExit.setBackground(new Color(220, 50, 50));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnExit.setOpaque(true);
        btnExit.setBorderPainted(false);
        btnExit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(btnExit);
        
        table = new JTable();
        table.setBounds(0, 180, 800, 300);
        table.setFont(new Font("Tahoma", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 12));
        table.setRowHeight(25);
        table.setTableHeader(null);
        table.setSelectionBackground(new Color(0, 120, 215));
        table.setSelectionForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 180, 800, 300);
        contentPane.add(scrollPane);
        
        JLabel lblNewLabel = new JLabel("Age");
        lblNewLabel.setBounds(155, 160, 100, 20);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        contentPane.add(lblNewLabel);
        
        JLabel lblGender = new JLabel("Gender");
        lblGender.setBounds(264, 160, 100, 20);
        lblGender.setFont(new Font("Tahoma", Font.BOLD, 14));
        contentPane.add(lblGender);
        
        JLabel lblTypeOfDriver = new JLabel("Company");
        lblTypeOfDriver.setBounds(366, 160, 100, 20);
        lblTypeOfDriver.setFont(new Font("Tahoma", Font.BOLD, 14));
        contentPane.add(lblTypeOfDriver);
        
        JLabel lblDateOfThe = new JLabel("Model");
        lblDateOfThe.setBounds(486, 160, 100, 20);
        lblDateOfThe.setFont(new Font("Tahoma", Font.BOLD, 14));
        contentPane.add(lblDateOfThe);
    
        JLabel lblAirport = new JLabel("Availability");
        lblAirport.setBounds(590, 160, 110, 20);
        lblAirport.setFont(new Font("Tahoma", Font.BOLD, 14));
        contentPane.add(lblAirport);
        
        JLabel lblAvailable = new JLabel("Location");
        lblAvailable.setBounds(700, 160, 100, 20);
        lblAvailable.setFont(new Font("Tahoma", Font.BOLD, 14));
        contentPane.add(lblAvailable);
        
        getContentPane().setBackground(Color.WHITE);
        
        // Make window draggable
        titlePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                titlePanelMousePressed(evt);
            }
        });
        titlePanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                titlePanelMouseDragged(evt);
            }
        });
    }
    
    // Variables for window dragging
    private int xMouse, yMouse;
    
    private void titlePanelMousePressed(java.awt.event.MouseEvent evt) {
        xMouse = evt.getX();
        yMouse = evt.getY();
    }
    
    private void titlePanelMouseDragged(java.awt.event.MouseEvent evt) {
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }
}