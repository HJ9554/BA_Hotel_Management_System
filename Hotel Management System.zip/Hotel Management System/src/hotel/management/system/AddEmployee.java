package hotel.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.regex.*;

public class AddEmployee extends JFrame implements ActionListener {

    JTextField tfname, tfage, tfsalary, tfemail, tfphone, tfaadhar;
    JRadioButton rbmale, rbfemale;
    JButton submit;
    JComboBox<String> cbjob;
    JLabel errorLabel;
    private Point lastPosition;

    AddEmployee() {
        // Window setup
        setUndecorated(true);
        getContentPane().setBackground(new Color(240, 240, 240));
        setBounds(350, 200, 850, 600);
        
        // Custom title bar
        JPanel titleBar = createTitleBar();
        
        // Main content panel
        JPanel mainPanel = createMainPanel();
        
        // Add components to frame
        setLayout(new BorderLayout());
        add(titleBar, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        
        setVisible(true);
        toFront();
        requestFocus();
    }
    
    private JPanel createTitleBar() {
        JPanel titleBar = new JPanel();
        titleBar.setBackground(new Color(70, 130, 180));
        titleBar.setLayout(new BorderLayout());
        titleBar.setPreferredSize(new Dimension(getWidth(), 40));

        JLabel title = new JLabel("  ADD EMPLOYEE DETAILS", SwingConstants.LEFT);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        
        JButton closeButton = new JButton("×");
        closeButton.setContentAreaFilled(false);
        closeButton.setBorderPainted(false);
        closeButton.setFocusPainted(false);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Arial", Font.BOLD, 20));
        closeButton.addActionListener(e -> dispose());
        
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(Color.RED);
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(Color.WHITE);
            }
        });
        
        titleBar.add(title, BorderLayout.WEST);
        titleBar.add(closeButton, BorderLayout.EAST);

        // Window dragging functionality
        titleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastPosition = e.getPoint();
            }
        });
        
        titleBar.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point currCoords = e.getLocationOnScreen();
                setLocation(currCoords.x - lastPosition.x, currCoords.y - lastPosition.y);
            }
        });

        return titleBar;
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setPreferredSize(new Dimension(800, 550));
        
        // Name Field
        addLabelAndTextField(mainPanel, "NAME", 60, 30, tfname = new JTextField());

        // Age Field
        addLabelAndTextField(mainPanel, "AGE", 60, 80, tfage = new JTextField());

        // Gender Radio Buttons
        addGenderRadioButtons(mainPanel);

        // Job ComboBox
        addJobComboBox(mainPanel);

        // Salary Field
        addLabelAndTextField(mainPanel, "SALARY", 60, 230, tfsalary = new JTextField());

        // Phone Field
        addLabelAndTextField(mainPanel, "PHONE", 60, 280, tfphone = new JTextField());

        // Aadhar Field
        addLabelAndTextField(mainPanel, "AADHAR", 60, 330, tfaadhar = new JTextField());

        // Email Field
        addLabelAndTextField(mainPanel, "EMAIL", 60, 380, tfemail = new JTextField());

        // Submit Button - Made more prominent
        submit = new JButton("SUBMIT");
        submit.addActionListener(this);
        submit.setBounds(150, 450, 150, 40);
        submit.setBackground(new Color(25, 25, 112));
        submit.setForeground(Color.WHITE);
        submit.setFocusPainted(false);
        submit.setOpaque(true);
        submit.setBorderPainted(false);
        submit.setFont(new Font("Tahoma", Font.BOLD, 14));
        submit.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        submit.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                submit.setBackground(new Color(65, 65, 165));
            }
            public void mouseExited(MouseEvent e) {
                submit.setBackground(new Color(25, 25, 112));
            }
        });
        mainPanel.add(submit);

        // Error Label
        errorLabel = new JLabel("");
        errorLabel.setForeground(Color.RED);
        errorLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        errorLabel.setBounds(200, 480, 400, 30);
        mainPanel.add(errorLabel);

        // Image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/tenth.jpg"));
        Image i3 = i1.getImage().getScaledInstance(400, 500, Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel image = new JLabel(i2);
        image.setBounds(400, 60, 400, 400);
        mainPanel.add(image);

        return mainPanel;
    }

    private void addLabelAndTextField(JPanel panel, String labelText, int x, int y, JTextField textField) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setBounds(x, y, 150, 27);
        panel.add(label);
        
        textField.setBounds(200, y, 150, 30);
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        panel.add(textField);
    }

    private void addGenderRadioButtons(JPanel panel) {
        JLabel lblgender = new JLabel("GENDER");
        lblgender.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblgender.setBounds(60, 130, 150, 27);
        panel.add(lblgender);
        
        rbmale = new JRadioButton("MALE");
        rbmale.setBackground(Color.WHITE);
        rbmale.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rbmale.setBounds(200, 130, 70, 30);
        panel.add(rbmale);

        rbfemale = new JRadioButton("FEMALE");
        rbfemale.setBackground(Color.WHITE);
        rbfemale.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rbfemale.setBounds(280, 130, 90, 30);
        panel.add(rbfemale);

        ButtonGroup bg = new ButtonGroup();
        bg.add(rbmale);
        bg.add(rbfemale);
    }

    private void addJobComboBox(JPanel panel) {
        JLabel lbljob = new JLabel("JOB");
        lbljob.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbljob.setBounds(60, 180, 150, 27);
        panel.add(lbljob);

        String str[] = {"Front Desk Clerks", "Porters", "Housekeeping", "Kitchen Staff", 
                       "Room Service", "Waiter/Waitress", "Manager", "Accountant", "Chef"};
        cbjob = new JComboBox<>(str);
        cbjob.setBackground(Color.WHITE);
        cbjob.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cbjob.setBounds(200, 180, 150, 30);
        panel.add(cbjob);
    }

    public void actionPerformed(ActionEvent ae) {
        if (!validateFields()) {
            return;
        }

        String name = tfname.getText().trim();
        String age = tfage.getText().trim();
        String salary = tfsalary.getText().trim();
        String phone = tfphone.getText().trim();
        String aadhar = tfaadhar.getText().trim();
        String email = tfemail.getText().trim();
        
        String gender = rbmale.isSelected() ? "Male" : rbfemale.isSelected() ? "Female" : null;
        String job = (String) cbjob.getSelectedItem();
        
        try {
            Conn conn = new Conn();
            String query = String.format("INSERT INTO employee values('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
                                      name, age, gender, job, salary, phone, email, aadhar);
            
            conn.s.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Employee Added Successfully");
            dispose();
        } catch (Exception e) {
            errorLabel.setText("Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private boolean validateFields() {
        // Name validation
        String name = tfname.getText().trim();
        if (name.isEmpty()) {
            showError("Name cannot be empty", tfname);
            return false;
        }
        if (!name.matches("^[a-zA-Z\\s]{2,50}$")) {
            showError("Invalid name (only letters and spaces, 2-50 chars)", tfname);
            return false;
        }
        
        // Age validation
        String ageStr = tfage.getText().trim();
        if (ageStr.isEmpty()) {
            showError("Age cannot be empty", tfage);
            return false;
        }
        try {
            int age = Integer.parseInt(ageStr);
            if (age < 18 || age > 70) {
                showError("Age must be between 18 and 70", tfage);
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Age must be a valid number", tfage);
            return false;
        }
        
        // Gender validation
        if (!rbmale.isSelected() && !rbfemale.isSelected()) {
            showError("Please select gender", rbmale);
            return false;
        }
        
        // Salary validation
        String salaryStr = tfsalary.getText().trim();
        if (salaryStr.isEmpty()) {
            showError("Salary cannot be empty", tfsalary);
            return false;
        }
        try {
            double salary = Double.parseDouble(salaryStr);
            if (salary <= 0) {
                showError("Salary must be positive", tfsalary);
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Salary must be a valid number", tfsalary);
            return false;
        }
        
        // Phone validation
        String phone = tfphone.getText().trim();
        if (phone.isEmpty()) {
            showError("Phone cannot be empty", tfphone);
            return false;
        }
        if (!phone.matches("^[0-9]{10}$")) {
            showError("Phone must be 10 digits", tfphone);
            return false;
        }
        
        // Aadhar validation
        String aadhar = tfaadhar.getText().trim();
        if (aadhar.isEmpty()) {
            showError("Aadhar cannot be empty", tfaadhar);
            return false;
        }
        if (!aadhar.matches("^[0-9]{12}$")) {
            showError("Aadhar must be 12 digits", tfaadhar);
            return false;
        }
        
        // Email validation
        String email = tfemail.getText().trim();
        if (email.isEmpty()) {
            showError("Email cannot be empty", tfemail);
            return false;
        }
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        if (!Pattern.compile(emailRegex).matcher(email).matches()) {
            showError("Invalid email format", tfemail);
            return false;
        }
        
        errorLabel.setText("");
        return true;
    }

    private void showError(String message, Component component) {
        errorLabel.setText(message);
        component.requestFocus();
    }

    public static void main(String[] args) {
            new AddEmployee();
       
    }
}