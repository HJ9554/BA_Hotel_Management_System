package hotel.management.system;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import javax.swing.JTable;
import java.sql.*;    
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Room extends JFrame {
    Connection conn = null;
    private JPanel contentPane;
    private JTable table;
    private JLabel lblAvailability;
    private JLabel lblCleanStatus;
    private JLabel lblPrice;
    private JLabel lblBedType;
    private JLabel lblRoomNumber;
    private JLabel lblId;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Room frame = new Room();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Room() throws SQLException {
        // Remove default title bar
        setUndecorated(true);
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(350, 150, 1100, 638);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        contentPane.setBackground(Color.WHITE); // Set background color
        
        // Background image first (so it's at the bottom of z-order)
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/eight.jpg"));
        Image i3 = i1.getImage().getScaledInstance(600, 500, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l1 = new JLabel(i2);
        l1.setBounds(500, 100, 600, 500); // Adjusted position to not overlap with controls
        contentPane.add(l1);
        
        // Custom Title Bar Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(128, 0, 128)); // Purple color
        titlePanel.setBounds(0, 0, 1100, 40);
        titlePanel.setLayout(null);
        contentPane.add(titlePanel);
        
        // Title Label
        JLabel titleLabel = new JLabel("Room Information");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(10, 5, 200, 30);
        titlePanel.add(titleLabel);
        
        // Close Button
        JButton closeButton = new JButton("X");
        closeButton.setBounds(1060, 5, 30, 30);
        closeButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        closeButton.setBackground(new Color(128, 0, 128));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBorder(BorderFactory.createEmptyBorder());
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(Color.RED);
                closeButton.setOpaque(true);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(null);
                closeButton.setOpaque(false);
            }
        });
        
        closeButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        titlePanel.add(closeButton);
        
        // Make window draggable
        titlePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                titlePanelMousePressed(evt);
            }
        });
        titlePanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                titlePanelMouseDragged(evt);
            }
        });
        
        // Table with scroll pane
        table = new JTable();
        table.setFont(new Font("Tahoma", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 12));
        table.setRowHeight(25);
        table.setSelectionBackground(new Color(128, 0, 128));
        table.setSelectionForeground(Color.WHITE);
        table.setTableHeader(null);
        table.setOpaque(true);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 100, 500, 400);
        scrollPane.setOpaque(true);
        contentPane.add(scrollPane);
        
        // Styled buttons
        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Conn c = new Conn();
                    String displayCustomersql = "select * from Room";
                    ResultSet rs = c.s.executeQuery(displayCustomersql);
                    table.setModel(DbUtils.resultSetToTableModel(rs));
                    table.setTableHeader(null);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        btnLoadData.setBounds(100, 550, 150, 40);
        btnLoadData.setBackground(new Color(128, 0, 128));
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnLoadData.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLoadData.setOpaque(true);
        btnLoadData.setBorderPainted(false);
        contentPane.add(btnLoadData);
        
        JButton btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Reception().setVisible(true);
                dispose(); // Changed from setVisible(false) to dispose()
            }
        });
        btnNewButton.setBounds(290, 550, 150, 40);
        btnNewButton.setBackground(new Color(70, 70, 70));
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnNewButton.setOpaque(true);
        btnNewButton.setBorderPainted(false);
        contentPane.add(btnNewButton);
        
        // Styled table headers
        lblAvailability = new JLabel("Availability");
        lblAvailability.setBounds(118, 80, 100, 20);
        lblAvailability.setFont(new Font("Tahoma", Font.BOLD, 12));
        contentPane.add(lblAvailability);
        
        lblCleanStatus = new JLabel("Clean Status");
        lblCleanStatus.setBounds(211, 80, 100, 20);
        lblCleanStatus.setFont(new Font("Tahoma", Font.BOLD, 12));
        contentPane.add(lblCleanStatus);
        
        lblPrice = new JLabel("Price");
        lblPrice.setBounds(330, 80, 100, 20);
        lblPrice.setFont(new Font("Tahoma", Font.BOLD, 12));
        contentPane.add(lblPrice);
        
        lblBedType = new JLabel("Bed Type");
        lblBedType.setBounds(417, 80, 100, 20);
        lblBedType.setFont(new Font("Tahoma", Font.BOLD, 12));
        contentPane.add(lblBedType);
        
        lblId = new JLabel("Room Number");
        lblId.setBounds(5, 80, 140, 20);
        lblId.setFont(new Font("Tahoma", Font.BOLD, 12));
        contentPane.add(lblId);
    }
    
    // Variables for window dragging
    private int xMouse, yMouse;
    
    private void titlePanelMousePressed(java.awt.event.MouseEvent evt) {
        xMouse = evt.getX();
        yMouse = evt.getY();
    }
    
    private void titlePanelMouseDragged(java.awt.event.MouseEvent evt) {
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }
}