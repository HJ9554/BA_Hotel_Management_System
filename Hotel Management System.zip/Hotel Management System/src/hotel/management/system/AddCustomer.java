package hotel.management.system;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import java.util.Date;
import java.awt.geom.RoundRectangle2D;
import java.awt.geom.Rectangle2D;

public class AddCustomer extends JFrame {
    Connection conn = null;
    PreparedStatement pst = null;
    private JPanel contentPane;
    private JTextField t1, t2, t3, t6;
    JComboBox<String> comboBox;
    JRadioButton r1, r2;
    Choice c1;
    JLabel t5;
    private int xMouse, yMouse;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                AddCustomer frame = new AddCustomer();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public AddCustomer() throws SQLException {
        // Frame setup without default title bar
        setUndecorated(true);
        setBounds(300, 60, 1000, 750);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setShape(new RoundRectangle2D.Double(0, 0, 1000, 750, 15, 15));
        
        // Main content pane with border
        contentPane = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(240, 248, 255));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            }
        };
        contentPane.setBorder(BorderFactory.createMatteBorder(0, 1, 1, 1, new Color(70, 130, 180)));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Custom title bar
        JPanel titleBar = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(70, 130, 180));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            }
        };
        titleBar.setBounds(0, 0, 1000, 40);
        titleBar.setLayout(null);
        titleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });
        titleBar.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                setLocation(x - xMouse, y - yMouse);
            }
        });
        contentPane.add(titleBar);

        // Title label
        JLabel titleLabel = new JLabel("Add New Customer");
        titleLabel.setBounds(20, 5, 300, 30);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleBar.add(titleLabel);

        // Close button
        JButton closeButton = new JButton("×");
        closeButton.setBounds(950, 0, 50, 40);
        closeButton.setFont(new Font("Arial", Font.BOLD, 24));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBorderPainted(false);
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                closeButton.setForeground(new Color(255, 100, 100));
            }
            public void mouseExited(MouseEvent e) {
                closeButton.setForeground(Color.WHITE);
            }
        });
        closeButton.addActionListener(e -> dispose());
        titleBar.add(closeButton);

        // Minimize button
        JButton minimizeButton = new JButton("-");
        minimizeButton.setBounds(900, 0, 50, 40);
        minimizeButton.setFont(new Font("Arial", Font.BOLD, 24));
        minimizeButton.setForeground(Color.WHITE);
        minimizeButton.setBorderPainted(false);
        minimizeButton.setFocusPainted(false);
        minimizeButton.setContentAreaFilled(false);
        minimizeButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                minimizeButton.setForeground(new Color(100, 149, 237));
            }
            public void mouseExited(MouseEvent e) {
                minimizeButton.setForeground(Color.WHITE);
            }
        });
        minimizeButton.addActionListener(e -> setState(JFrame.ICONIFIED));
        titleBar.add(minimizeButton);

        // Form header
        JLabel lblName = new JLabel("NEW CUSTOMER FORM");
        lblName.setFont(new Font("Yu Mincho", Font.BOLD, 24));
        lblName.setForeground(new Color(70, 130, 180));
        lblName.setBounds(120, 60, 300, 40);
        contentPane.add(lblName);

        // Right side image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/newcust.png"));
        Image i3 = i1.getImage().getScaledInstance(300, 400, Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l1 = new JLabel(i2);
        l1.setBounds(580, 60, 300, 600);
        contentPane.add(l1);

        // Form fields with validation
        addFormField("ID Type:", 50, 140, comboBox = new JComboBox<>(new String[]{"Passport", "Aadhar Card", "Voter Id", "Driving license"}));
        addFormField("Number:", 50, 210, t1 = new JTextField());
        addFormField("Name:", 50, 280, t2 = new JTextField());
        
        // Gender radio buttons with validation
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        genderPanel.setBounds(300, 330, 250, 40);
        genderPanel.setBackground(new Color(240, 248, 255));
        genderPanel.setOpaque(false);

        r1 = new JRadioButton("Male");
        r1.setFont(new Font("Tahoma", Font.PLAIN, 16));
        r1.setBackground(new Color(240, 248, 255));
        r1.setOpaque(false);

        r2 = new JRadioButton("Female");
        r2.setFont(new Font("Tahoma", Font.PLAIN, 16));
        r2.setBackground(new Color(240, 248, 255));
        r2.setOpaque(false);

        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        genderPanel.add(r1);
        genderPanel.add(Box.createHorizontalStrut(20));
        genderPanel.add(r2);

        contentPane.add(createLabel("Gender:", 50, 340));
        contentPane.add(genderPanel);

        addFormField("Country:", 50, 400, t3 = new JTextField());
        
        // Room number choice with validation
        c1 = new Choice();
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from room where availability = 'Available'");
            while (rs.next()) {
                c1.add(rs.getString("roomnumber"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        contentPane.add(createLabel("Allocated Room Number:", 50, 470));
        c1.setBounds(300, 470, 250, 30);
        c1.setBackground(Color.WHITE);
        c1.setFont(new Font("Raleway", Font.PLAIN, 14));
        contentPane.add(c1);

        // Check-in date
        Date date = new Date();
        t5 = new JLabel("" + date);
        contentPane.add(createLabel("Checked-In:", 50, 540));
        t5.setBounds(300, 540, 300, 30);
        t5.setFont(new Font("Raleway", Font.PLAIN, 14));
        t5.setForeground(new Color(70, 130, 180));
        contentPane.add(t5);

        addFormField("Deposit:", 50, 610, t6 = new JTextField());

        // Add button with validation
        JButton btnNewButton = createButton("Add", 300, 670, e -> {
            if (!validateFields()) {
                return;
            }

            Conn c = new Conn();
            String radio = r1.isSelected() ? "Male" : "Female";
            String s6 = c1.getSelectedItem();

            try {
                String s1 = (String) comboBox.getSelectedItem();
                String s2 = t1.getText().trim();
                String s3 = t2.getText().trim();
                String s4 = radio;
                String s5 = t3.getText().trim();
                String s7 = t5.getText();
                String s8 = t6.getText().trim();

                // Check for existing customer
                ResultSet rs = c.s.executeQuery("SELECT * FROM customer WHERE number = '" + s2 + "'");
                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, 
                        "Customer with this ID already exists", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String q1 = "INSERT INTO customer VALUES('" + s1 + "','" + s2 + "','" + s3 + "','" + s4 + "','" + s5 + "','" + s6 + "','" + s7 + "','" + s8 + "')";
                String q2 = "UPDATE room SET availability = 'Occupied' WHERE roomnumber = " + s6;
                
                c.s.executeUpdate(q1);
                c.s.executeUpdate(q2);

                JOptionPane.showMessageDialog(null, "Customer Added Successfully");
                new Reception().setVisible(true);
                dispose();
            } catch (SQLException e1) {
                JOptionPane.showMessageDialog(null, 
                    "Database Error: " + e1.getMessage(), 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        contentPane.add(btnNewButton);

        // Back button
        JButton btnExit = createButton("Back", 500, 670, e -> {
            new Reception().setVisible(true);
            dispose();
        });
        contentPane.add(btnExit);
    }

    private boolean validateFields() {
        // Validate ID Number
        if (t1.getText().trim().isEmpty()) {
            showError("Please enter ID Number", t1);
            return false;
        } else if (t1.getText().length() < 4) {
            showError("ID Number must be at least 4 characters", t1);
            return false;
        }

        // Validate Name
        if (t2.getText().trim().isEmpty()) {
            showError("Please enter Name", t2);
            return false;
        } else if (!t2.getText().matches("[a-zA-Z ]+")) {
            showError("Name should contain only letters", t2);
            return false;
        } else if (t2.getText().length() < 3) {
            showError("Name must be at least 3 characters", t2);
            return false;
        }

        // Validate Gender
        if (!r1.isSelected() && !r2.isSelected()) {
            JOptionPane.showMessageDialog(this, 
                "Please select Gender", 
                "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Validate Country
        if (t3.getText().trim().isEmpty()) {
            showError("Please enter Country", t3);
            return false;
        } else if (!t3.getText().matches("[a-zA-Z ]+")) {
            showError("Country should contain only letters", t3);
            return false;
        }

        // Validate Room Selection
        if (c1.getSelectedItem() == null || c1.getSelectedItem().toString().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please select a Room", 
                "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Validate Deposit
        try {
            if (t6.getText().trim().isEmpty()) {
                showError("Please enter Deposit amount", t6);
                return false;
            }
            
            double deposit = Double.parseDouble(t6.getText());
            if (deposit <= 0) {
                showError("Deposit must be greater than 0", t6);
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Please enter a valid Deposit amount", t6);
            return false;
        }

        return true;
    }

    private void showError(String message, JComponent component) {
        JOptionPane.showMessageDialog(this, 
            message, 
            "Validation Error", JOptionPane.ERROR_MESSAGE);
        component.requestFocus();
    }

    private JLabel createLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, 220, 30);
        label.setFont(new Font("Raleway", Font.BOLD, 16));
        label.setForeground(new Color(70, 130, 180));
        return label;
    }

    private void addFormField(String labelText, int x, int y, JComponent field) {
        contentPane.add(createLabel(labelText, x, y));
        field.setBounds(300, y, 250, 35);
        field.setFont(new Font("Raleway", Font.PLAIN, 14));
        
        if (field instanceof JTextField) {
            JTextField textField = (JTextField) field;
            textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(70, 130, 180)),
                    BorderFactory.createEmptyBorder(0, 10, 0, 10)));
            
            // Add input validation based on field type
            if (labelText.equals("Number:")) {
                textField.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!(Character.isDigit(c) || 
                             (c == KeyEvent.VK_BACK_SPACE) || 
                             (c == KeyEvent.VK_DELETE))) {
                            e.consume();
                        }
                    }
                });
            } else if (labelText.equals("Name:")) {
                textField.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!(Character.isLetter(c) || 
                             Character.isWhitespace(c) || 
                             (c == KeyEvent.VK_BACK_SPACE) || 
                             (c == KeyEvent.VK_DELETE))) {
                            e.consume();
                        }
                    }
                });
            } else if (labelText.equals("Deposit:")) {
                textField.addKeyListener(new KeyAdapter() {
                    public void keyTyped(KeyEvent e) {
                        char c = e.getKeyChar();
                        if (!(Character.isDigit(c) || 
                             (c == '.') || 
                             (c == KeyEvent.VK_BACK_SPACE) || 
                             (c == KeyEvent.VK_DELETE))) {
                            e.consume();
                        }
                    }
                });
            }
        } else if (field instanceof JComboBox) {
            ((JComboBox<?>) field).setBackground(Color.WHITE);
        }
        contentPane.add(field);
    }

    private JButton createButton(String text, int x, int y, ActionListener action) {
        JButton button = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Shadow
                g2.setColor(new Color(0, 0, 0, 30));
                g2.fillRoundRect(2, 3, getWidth()-4, getHeight()-4, 10, 10);
                
                // Button
                if (text.equals("Add")) {
                    g2.setColor(new Color(76, 175, 80)); // Green for Add
                } else {
                    g2.setColor(new Color(66, 165, 245)); // Blue for Back
                }
                g2.fillRoundRect(0, 0, getWidth()-4, getHeight()-4, 10, 10);
                
                // Text
                g2.setColor(Color.WHITE);
                FontMetrics fm = g2.getFontMetrics();
                Rectangle2D r = fm.getStringBounds(getText(), g2);
                int textX = (int)((getWidth()-4 - r.getWidth())/2);
                int textY = (int)((getHeight()-4 - r.getHeight())/2 + fm.getAscent());
                g2.drawString(getText(), textX, textY);
                g2.dispose();
            }
            
            protected void paintBorder(Graphics g) {}
        };
        
        button.setBounds(x, y, 180, 45);
        button.setFont(new Font("Raleway", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setContentAreaFilled(false);
        button.setBorder(BorderFactory.createEmptyBorder());
        button.addActionListener(action);
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (text.equals("Add")) {
                    button.setBackground(new Color(56, 142, 60)); // Darker green
                } else {
                    button.setBackground(new Color(41, 121, 255)); // Darker blue
                }
                button.repaint();
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            public void mouseExited(MouseEvent e) {
                if (text.equals("Add")) {
                    button.setBackground(new Color(76, 175, 80)); // Original green
                } else {
                    button.setBackground(new Color(66, 165, 245)); // Original blue
                }
                button.repaint();
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });
        
        return button;
    }
}