package hotel.management.system;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.regex.Pattern;

public class UpdateRoom extends JFrame implements ActionListener {
    
    private Choice ccustomer;
    private JTextField tfroom, tfavailable, tfstatus;
    private JButton check, update, back;
    private JPanel titlePanel;
    
    UpdateRoom() {
        // Frame setup without default title bar
        setUndecorated(true);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setBounds(300, 200, 980, 450);
        
        // Custom title bar
        createCustomTitleBar();
        
        // Main content
        JLabel text = new JLabel("Update Room Status");
        text.setFont(new Font("Tahoma", Font.BOLD, 25));
        text.setBounds(30, 50, 300, 30);
        text.setForeground(new Color(0, 102, 204));
        add(text);
        
        // Customer ID Section
        JLabel lblid = new JLabel("Customer ID");
        lblid.setBounds(30, 110, 150, 20);
        lblid.setFont(new Font("Tahoma", Font.PLAIN, 14));
        add(lblid);
        
        ccustomer = new Choice();
        ccustomer.setBounds(200, 110, 200, 25);
        ccustomer.setFont(new Font("Tahoma", Font.PLAIN, 14));
        add(ccustomer);
        
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM customer");
            while(rs.next()) {
                ccustomer.add(rs.getString("number"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed to load customer data: " + e.getMessage());
        }
        
        // Room Number Section
        JLabel lblroom = new JLabel("Room Number");
        lblroom.setBounds(30, 160, 150, 20);
        lblroom.setFont(new Font("Tahoma", Font.PLAIN, 14));
        add(lblroom);
        
        tfroom = new JTextField();
        tfroom.setBounds(200, 160, 200, 30);
        tfroom.setFont(new Font("Tahoma", Font.PLAIN, 14));
        tfroom.setEditable(false);
        add(tfroom);
        
        // Availability Section
        JLabel lblname = new JLabel("Availability");
        lblname.setBounds(30, 210, 150, 20);
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 14));
        add(lblname);
        
        tfavailable = new JTextField();
        tfavailable.setBounds(200, 210, 200, 30);
        tfavailable.setFont(new Font("Tahoma", Font.PLAIN, 14));
        add(tfavailable);
        
        // Cleaning Status Section
        JLabel lblcheckin = new JLabel("Cleaning Status");
        lblcheckin.setBounds(30, 260, 150, 20);
        lblcheckin.setFont(new Font("Tahoma", Font.PLAIN, 14));
        add(lblcheckin);
        
        tfstatus = new JTextField();
        tfstatus.setBounds(200, 260, 200, 30);
        tfstatus.setFont(new Font("Tahoma", Font.PLAIN, 14));
        add(tfstatus);
        
        // Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(30, 320, 370, 50);
        buttonPanel.setLayout(new GridLayout(1, 3, 10, 0));
        buttonPanel.setBackground(Color.WHITE);
        
        check = createButton("Check");
        update = createButton("Update");
        back = createButton("Back");
        
        buttonPanel.add(check);
        buttonPanel.add(update);
        buttonPanel.add(back);
        add(buttonPanel);
        
        // Image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/seventh.jpg"));
        Image i2 = i1.getImage().getScaledInstance(500, 300, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(450, 80, 500, 300);
        add(image);
        
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void createCustomTitleBar() {
        titlePanel = new JPanel();
        titlePanel.setBounds(0, 0, 980, 40);
        titlePanel.setBackground(new Color(0, 102, 204));
        titlePanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Hotel Management System - Update Room");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        titlePanel.add(titleLabel, BorderLayout.WEST);
        
        // Close button
        JButton closeButton = new JButton("×");
        closeButton.setFont(new Font("Arial", Font.BOLD, 20));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(new Color(0, 102, 204));
        closeButton.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 15));
        closeButton.setFocusPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setOpaque(true);
        
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(new Color(204, 0, 0));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(new Color(0, 102, 204));
            }
        });
        closeButton.addActionListener(e -> dispose());
        
        titlePanel.add(closeButton, BorderLayout.EAST);
        add(titlePanel);
        
        // Add mouse listener for window dragging
        titlePanel.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent me) {
                mouseX = me.getX();
                mouseY = me.getY();
            }
        });
        titlePanel.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent me) {
                int x = me.getXOnScreen();
                int y = me.getYOnScreen();
                setLocation(x - mouseX, y - mouseY);
            }
        });
    }
    
    private int mouseX, mouseY;
    
    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 102, 204));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Tahoma", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        button.addActionListener(this);
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(0, 153, 255));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(0, 102, 204));
            }
        });
        
        return button;
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == check) {
            checkRoomDetails();
        } else if (ae.getSource() == update) {
            updateRoomDetails();
        } else if (ae.getSource() == back) {
            goBack();
        }
    }
    
    private void checkRoomDetails() {
        String id = ccustomer.getSelectedItem();
        if (id == null || id.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a customer ID");
            return;
        }
        
        String query = "SELECT * FROM customer WHERE number = '" + id + "'";
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery(query);
            if (rs.next()) {
                tfroom.setText(rs.getString("room"));
                
                ResultSet rs2 = c.s.executeQuery("SELECT * FROM room WHERE roomnumber = '" + tfroom.getText() + "'");
                if (rs2.next()) {
                    tfavailable.setText(rs2.getString("availability"));
                    tfstatus.setText(rs2.getString("cleaning_status"));
                } else {
                    JOptionPane.showMessageDialog(null, "Room details not found");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Customer not found");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    private void updateRoomDetails() {
        String room = tfroom.getText();
        String available = tfavailable.getText();
        String status = tfstatus.getText();
        
        // Validations
        if (room == null || room.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please check room details first");
            return;
        }
        
        if (available == null || available.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Availability cannot be empty");
            return;
        }
        
        if (status == null || status.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Cleaning status cannot be empty");
            return;
        }
        
        // Validate availability format (should be "Available" or "Occupied")
        if (!Pattern.matches("(?i)(available|occupied)", available.trim())) {
            JOptionPane.showMessageDialog(null, "Availability must be either 'Available' or 'Occupied'");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(
            null, 
            "Are you sure you want to update room " + room + "?\n" +
            "Availability: " + available + "\n" +
            "Status: " + status,
            "Confirm Update",
            JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                Conn c = new Conn();
                c.s.executeUpdate("UPDATE room SET availability = '" + available + 
                                 "', cleaning_status = '" + status + 
                                 "' WHERE roomnumber = '" + room + "'");
                
                JOptionPane.showMessageDialog(null, "Room updated successfully");
                resetFields();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Update failed: " + e.getMessage());
            }
        }
    }
    
    private void resetFields() {
        tfroom.setText("");
        tfavailable.setText("");
        tfstatus.setText("");
    }
    
    private void goBack() {
        this.dispose();
        new Reception();
    }
    
    public static void main(String[] args) {
            new UpdateRoom();
        
    }
}