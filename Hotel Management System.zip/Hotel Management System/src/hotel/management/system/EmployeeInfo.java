package hotel.management.system;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.proteanit.sql.DbUtils;
import javax.swing.JTable;
import java.sql.*;	
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EmployeeInfo extends JFrame {
    Connection conn = null;
    private JPanel contentPane;
    private JTable table;
    private JLabel lblNewLabel;
    private JLabel lblJob;
    private JLabel lblName;
    private JLabel lblDepartment;
    private int xMouse, yMouse;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    EmployeeInfo frame = new EmployeeInfo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void close() {
        this.dispose();
    }

    public EmployeeInfo() throws SQLException {
        // Remove default window decorations
        setUndecorated(true);
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(400, 100, 1030, 700);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // Custom Title Bar
        JPanel titleBar = new JPanel();
        titleBar.setBackground(new Color(70, 130, 180));
        titleBar.setBounds(0, 0, 1030, 30);
        titleBar.setLayout(null);
        titleBar.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });
        titleBar.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                setLocation(x - xMouse, y - yMouse);
            }
        });
        contentPane.add(titleBar);
        
        // Title Label
        JLabel titleLabel = new JLabel("Employee Information");
        titleLabel.setBounds(10, 0, 200, 30);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleBar.add(titleLabel);
        
        // Close Button
        JLabel closeButton = new JLabel("X");
        closeButton.setBounds(1000, 0, 30, 30);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeButton.setHorizontalAlignment(SwingConstants.CENTER);
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(Color.RED);
                closeButton.setOpaque(true);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(null);
                closeButton.setOpaque(false);
            }
        });
        titleBar.add(closeButton);
        
        // Main heading
        JLabel heading = new JLabel("Employee Information");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 24));
        heading.setBounds(380, 40, 300, 50);
        heading.setForeground(new Color(70, 130, 180));
        contentPane.add(heading);
        
        // Table with scroll pane
        table = new JTable();
        table.setBackground(new Color(240, 248, 255));
        table.setSelectionBackground(new Color(70, 130, 180));
        table.setSelectionForeground(Color.WHITE);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setTableHeader(null);
        table.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 150, 1000, 400);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 1));
        contentPane.add(scrollPane);
        
        // Column headers
        lblNewLabel = new JLabel("Name");
        lblNewLabel.setBounds(41, 130, 46, 14);
        lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblNewLabel.setForeground(new Color(70, 130, 180));
        contentPane.add(lblNewLabel);
        
        lblJob = new JLabel("Age");
        lblJob.setBounds(159, 130, 46, 14);
        lblJob.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblJob.setForeground(new Color(70, 130, 180));
        contentPane.add(lblJob);
        
        lblName = new JLabel("Gender");
        lblName.setBounds(273, 130, 46, 14);
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblName.setForeground(new Color(70, 130, 180));
        contentPane.add(lblName);
        
        lblDepartment = new JLabel("Job");
        lblDepartment.setBounds(416, 130, 86, 14);
        lblDepartment.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblDepartment.setForeground(new Color(70, 130, 180));
        contentPane.add(lblDepartment);
        
        JLabel l1 = new JLabel("Salary");
        l1.setBounds(536, 130, 86, 14);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l1.setForeground(new Color(70, 130, 180));
        contentPane.add(l1);
        
        JLabel l2 = new JLabel("Phone");
        l2.setBounds(656, 130, 86, 14);
        l2.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l2.setForeground(new Color(70, 130, 180));
        contentPane.add(l2);
        
        JLabel l3 = new JLabel("Email");
        l3.setBounds(786, 130, 86, 14);
        l3.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l3.setForeground(new Color(70, 130, 180));
        contentPane.add(l3);
        
        JLabel l4 = new JLabel("Aadhar");
        l4.setBounds(896, 130, 86, 14);
        l4.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l4.setForeground(new Color(70, 130, 180));
        contentPane.add(l4);
        
        // Load Data Button with validation
        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
            Conn c = new Conn();
            String displayCustomersql = "select name, age, gender, job, salary, phone, email, aadhar from Employee";
            ResultSet rs = c.s.executeQuery(displayCustomersql);
            
            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "No employee records found!", "Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                table.setModel(DbUtils.resultSetToTableModel(rs));
                table.setTableHeader(null);
            }
        } catch (Exception e1) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e1.printStackTrace();
        }
    }
});
        btnLoadData.setBounds(360, 580, 120, 35);
        btnLoadData.setBackground(new Color(70, 130, 180));
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnLoadData.setFocusPainted(false);
        btnLoadData.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btnLoadData.setOpaque(true);
        btnLoadData.setBorderPainted(false);
        contentPane.add(btnLoadData);
        
        // Back Button
        JButton btnExit = new JButton("Back");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Reception().setVisible(true);
                dispose();
            }
        });
        btnExit.setBounds(520, 580, 120, 35);
        btnExit.setBackground(new Color(220, 20, 60));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnExit.setFocusPainted(false);
        btnExit.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btnExit.setOpaque(true);
        btnExit.setBorderPainted(false);
        contentPane.add(btnExit);
        
        // Background color
        contentPane.setBackground(Color.WHITE);
        
        // Add some decorative elements
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 90, 1000, 2);
        separator.setForeground(new Color(70, 130, 180));
        contentPane.add(separator);
    }
}